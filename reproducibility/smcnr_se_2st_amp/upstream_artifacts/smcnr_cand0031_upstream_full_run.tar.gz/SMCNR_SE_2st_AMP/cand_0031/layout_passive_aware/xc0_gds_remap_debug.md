# GDS Remap Report

## Summary

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\gds\SMCNR_SE_2st_AMP_xc0.gds`
- Output GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_aware\xc0.sky130.debug.gds`
- Export map: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\sky130PDK_trial\sky130_gds_export_map.yaml`
- Unique input layer/datatype pairs: 17
- Successfully remapped pairs: 7
- Preserved TBD pairs: 10
- Preserved unmapped pairs: 0

The original MAGICAL GDS is not modified. This post-processing step rewrites confirmed MAGICAL internal layers to their proposed Sky130 GDS layer/datatype targets. TBD and unmapped layers are left unchanged.

## Layer Actions

| input layer | input datatype | element type | output layer | output datatype | action | mapping |
| ---: | ---: | --- | ---: | ---: | --- | --- |
| 32 | 0 | BOUNDARY | 68 | 20 | remapped | M2 -> met1 68/20 |
| 33 | 0 | BOUNDARY | 69 | 20 | remapped | M3 -> met2 69/20 |
| 34 | 0 | BOUNDARY | 70 | 20 | remapped | M4 -> met3 70/20 |
| 35 | 0 | BOUNDARY | 71 | 20 | remapped | M5 -> met4 71/20 |
| 52 | 0 | BOUNDARY | 68 | 44 | remapped | VIA2 -> via 68/44 |
| 53 | 0 | BOUNDARY | 69 | 44 | remapped | VIA3 -> via2 69/44 |
| 54 | 0 | BOUNDARY | 70 | 44 | remapped | VIA4 -> via3 70/44 |
| 150 | 2 | BOUNDARY | 150 | 2 | preserved_tbd | MRDMY -> TBD |
| 150 | 3 | BOUNDARY | 150 | 3 | preserved_tbd | MRDMY -> TBD |
| 150 | 4 | BOUNDARY | 150 | 4 | preserved_tbd | MRDMY -> TBD |
| 150 | 5 | BOUNDARY | 150 | 5 | preserved_tbd | MRDMY -> TBD |
| 155 | 2 | BOUNDARY | 155 | 2 | preserved_tbd | TSV_PPI -> TBD |
| 155 | 3 | BOUNDARY | 155 | 3 | preserved_tbd | TSV_PPI -> TBD |
| 155 | 4 | BOUNDARY | 155 | 4 | preserved_tbd | TSV_PPI -> TBD |
| 155 | 5 | BOUNDARY | 155 | 5 | preserved_tbd | TSV_PPI -> TBD |
| 155 | 27 | BOUNDARY | 155 | 27 | preserved_tbd | TSV_PPI -> TBD |
| 155 | 100 | BOUNDARY | 155 | 100 | preserved_tbd | TSV_PPI -> TBD |

## Notes

- `remapped` means both GDS layer and datatype were replaced from `sky130_gds_export_map.yaml`.
- `preserved_tbd` means the MAGICAL layer exists in the export map but its Sky130 target is not confirmed.
- `preserved_unmapped` means the input GDS layer is not listed in the export map.
- This remap is a layer/datatype translation only; it does not make the layout Sky130 DRC-clean.
