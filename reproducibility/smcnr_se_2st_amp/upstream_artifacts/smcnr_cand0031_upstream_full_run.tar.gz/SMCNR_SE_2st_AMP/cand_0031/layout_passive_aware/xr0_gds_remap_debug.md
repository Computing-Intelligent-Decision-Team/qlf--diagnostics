# GDS Remap Report

## Summary

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\gds\SMCNR_SE_2st_AMP_xr0.gds`
- Output GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_aware\xr0.sky130.debug.gds`
- Export map: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\sky130PDK_trial\sky130_gds_export_map.yaml`
- Unique input layer/datatype pairs: 7
- Successfully remapped pairs: 5
- Preserved TBD pairs: 2
- Preserved unmapped pairs: 0

The original MAGICAL GDS is not modified. This post-processing step rewrites confirmed MAGICAL internal layers to their proposed Sky130 GDS layer/datatype targets. TBD and unmapped layers are left unchanged.

## Layer Actions

| input layer | input datatype | element type | output layer | output datatype | action | mapping |
| ---: | ---: | --- | ---: | ---: | --- | --- |
| 17 | 0 | BOUNDARY | 66 | 20 | remapped | PO -> poly.drawing 66/20 |
| 25 | 0 | BOUNDARY | 94 | 20 | remapped | PP -> psdm.drawing 94/20 |
| 29 | 0 | BOUNDARY | 86 | 20 | remapped | RPO -> RPM 86/20 |
| 30 | 0 | BOUNDARY | 66 | 44 | remapped | CO -> licon1.drawing 66/44 |
| 31 | 0 | BOUNDARY | 67 | 20 | remapped | M1 -> li1 67/20 |
| 115 | 1 | BOUNDARY | 115 | 1 | preserved_tbd | RPDMY -> TBD |
| 117 | 0 | BOUNDARY | 117 | 0 | preserved_tbd | RH -> TBD |

## Notes

- `remapped` means both GDS layer and datatype were replaced from `sky130_gds_export_map.yaml`.
- `preserved_tbd` means the MAGICAL layer exists in the export map but its Sky130 target is not confirmed.
- `preserved_unmapped` means the input GDS layer is not listed in the export map.
- This remap is a layer/datatype translation only; it does not make the layout Sky130 DRC-clean.
