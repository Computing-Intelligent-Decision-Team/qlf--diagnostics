# Passive Geometry Strip Margin Probe

| name | stripped elements | supply short |
| --- | ---: | --- |
| `contains_margin_0` | 1604 | `True` |
| `contains_margin_100` | 1604 | `True` |
| `contains_margin_500` | 1645 | `True` |
| `contains_margin_1000` | 1661 | `True` |
| `contains_margin_2000` | 2778 | `False` |
| `contains_margin_5000` | 3318 | `False` |
| `contains_margin_10000` | 4381 | `False` |
| `intersects_margin_0` | 1611 | `False` |
| `intersects_margin_100` | 1612 | `False` |
| `intersects_margin_500` | 1658 | `False` |
| `intersects_margin_1000` | 1691 | `False` |
| `intersects_margin_2000` | 2825 | `False` |
| `intersects_margin_5000` | 3395 | `False` |
| `intersects_margin_10000` | 4424 | `False` |

- Supply short removed by: `['contains_margin_2000', 'contains_margin_5000', 'contains_margin_10000', 'intersects_margin_0', 'intersects_margin_100', 'intersects_margin_500', 'intersects_margin_1000', 'intersects_margin_2000', 'intersects_margin_5000', 'intersects_margin_10000']`