# MOS Connectivity Comparison

## Summary

- Status: `mos_internal_net_mismatch`
- Reason: Candidate MOS connectivity differs from the reference MOS role signatures.
- Full passive-aware LVS proven: `False`
- Issues: `candidate_pfet_source_or_bulk_tied_to_vss, candidate_pfet_bulk_on_non_vdd_internal_net, missing_reference_mos_net_role_signatures`

## Device Counts

- Reference MOS devices: 8
- Candidate MOS devices: 8
- Reference classes: `{'pfet': 5, 'nfet': 3}`
- Candidate classes: `{'pfet': 5, 'nfet': 3}`

## Supply Role Check

- Reference supply roles: `{'vdd': 'vdda', 'vss': 'gnda', 'nfet_source_to_vss': 1, 'nfet_source_to_vdd': 0, 'nfet_source_other': 2, 'nfet_bulk_to_vss': 3, 'nfet_bulk_to_vdd': 0, 'nfet_bulk_other': 0, 'nfet_source_or_bulk_to_vss': 4, 'nfet_source_or_bulk_to_vdd': 0, 'nfet_source_or_bulk_other': 2, 'pfet_source_to_vdd': 2, 'pfet_source_to_vss': 0, 'pfet_source_other': 3, 'pfet_bulk_to_vdd': 5, 'pfet_bulk_to_vss': 0, 'pfet_bulk_other': 0, 'pfet_source_or_bulk_to_vdd': 7, 'pfet_source_or_bulk_to_vss': 0, 'pfet_source_or_bulk_other': 3, 'nfet_with_source_or_bulk_not_vss': [], 'pfet_with_source_or_bulk_not_vdd': []}`
- Candidate supply roles: `{'vdd': 'vdda', 'vss': 'gnda', 'nfet_source_to_vss': 1, 'nfet_source_to_vdd': 0, 'nfet_source_other': 2, 'nfet_bulk_to_vss': 3, 'nfet_bulk_to_vdd': 0, 'nfet_bulk_other': 0, 'nfet_source_or_bulk_to_vss': 4, 'nfet_source_or_bulk_to_vdd': 0, 'nfet_source_or_bulk_other': 2, 'pfet_source_to_vdd': 0, 'pfet_source_to_vss': 0, 'pfet_source_other': 5, 'pfet_bulk_to_vdd': 1, 'pfet_bulk_to_vss': 1, 'pfet_bulk_other': 3, 'pfet_source_or_bulk_to_vdd': 1, 'pfet_source_or_bulk_to_vss': 1, 'pfet_source_or_bulk_other': 8, 'nfet_with_source_or_bulk_not_vss': [], 'pfet_with_source_or_bulk_not_vdd': [{'instance': 'X0', 'source': 'w_445_3245#', 'bulk': 'w_445_3245#', 'line': 'X0 vout ibias w_445_3245# w_445_3245# sky130_fd_pr__pfet_01v8 ad=0.0385 pd=0.79 as=0.0385 ps=0.79 w=0.22 l=10'}, {'instance': 'X1', 'source': 'a_n15_2446#', 'bulk': 'gnda', 'line': 'X1 gnda ibias a_n15_2446# gnda sky130_fd_pr__pfet_01v8 ad=0.0385 pd=0.79 as=0.0385 ps=0.79 w=0.22 l=10'}, {'instance': 'X4', 'source': 'w_2325_2325#', 'bulk': 'w_2325_2325#', 'line': 'X4 a_3264_586# ibias w_2325_2325# w_2325_2325# sky130_fd_pr__pfet_01v8 ad=0.0385 pd=0.79 as=0.0385 ps=0.79 w=0.22 l=10'}, {'instance': 'X6', 'source': 'w_445_3245#', 'bulk': 'w_1485_445#', 'line': 'X6 a_3264_586# vip w_445_3245# w_1485_445# sky130_fd_pr__pfet_01v8 ad=1.1656 pd=15.35 as=1.1656 ps=15.35 w=7.52 l=8.24'}]}`

## Netgen Cross-Check

- Disconnected nodes: `[]`
- Net mismatch: `None`
- Source net count: `None`
- Candidate net count: `None`

## Missing Reference Net Role Signatures

- reference nets `['gnda']` with roles `{'nfet.bulk': 3, 'nfet.drain': 2, 'nfet.source': 1}`
- reference nets `['ibias']` with roles `{'pfet.gate': 3, 'pfet.source': 1}`
- reference nets `['outn']` with roles `{'nfet.gate': 1, 'nfet.source': 1, 'pfet.source': 1}`
- reference nets `['outp']` with roles `{'nfet.gate': 2, 'nfet.source': 1, 'pfet.drain': 1}`
- reference nets `['vdda']` with roles `{'pfet.bulk': 5, 'pfet.drain': 1, 'pfet.source': 2}`

## Interpretation

This diagnostic compares MOS terminal-role connectivity only. A pass here would still not prove full passive-aware LVS; it would only show that the full passive-remapped extraction has not corrupted the MOS network relative to the MOS-only reference.
