# Passive Geometry Strip Diagnostic

## Summary

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- Output GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\passive_geometry_strip_probe\intersects_margin_10000\SMCNR_SE_2st_AMP.intersects_margin_10000.gds`
- Mode: `intersects`
- Margin: `10000`
- Strip boxes: 2
- Stripped elements: 4424
- Kept elements: 2437
- Missing passive instances: `[]`

## Strip Boxes

| instance | placement | local bbox | strip bbox |
| --- | --- | --- | --- |
| `xr0` | `[14800, 14200]` | `[-275, -550, 4875, 20350]` | `[4525, 3650, 29675, 44550]` |
| `xc0` | `[400, 18400]` | `[-55, -50, 13055, 10650]` | `[-9655, 8350, 23455, 39050]` |

## Stripped By Layer

| layer/type | count |
| --- | ---: |
| `115/1/BOUNDARY` | 31 |
| `117/0/BOUNDARY` | 1 |
| `131/0/TEXT` | 4 |
| `136/0/TEXT` | 1 |
| `150/2/BOUNDARY` | 1 |
| `150/3/BOUNDARY` | 1 |
| `150/4/BOUNDARY` | 1 |
| `150/5/BOUNDARY` | 1 |
| `155/100/BOUNDARY` | 1 |
| `155/2/BOUNDARY` | 1 |
| `155/27/BOUNDARY` | 1 |
| `155/3/BOUNDARY` | 1 |
| `155/4/BOUNDARY` | 1 |
| `155/5/BOUNDARY` | 1 |
| `208/1/BOUNDARY` | 6 |
| `64/20/BOUNDARY` | 10 |
| `65/20/BOUNDARY` | 45 |
| `66/20/BOUNDARY` | 43 |
| `66/44/BOUNDARY` | 1499 |
| `67/16/BOUNDARY` | 4 |
| `67/20/BOUNDARY` | 239 |
| `67/44/BOUNDARY` | 233 |
| `67/5/TEXT` | 4 |
| `68/20/BOUNDARY` | 218 |
| `68/44/BOUNDARY` | 387 |
| `69/20/BOUNDARY` | 206 |
| `69/44/BOUNDARY` | 385 |
| `70/20/BOUNDARY` | 206 |
| `70/44/BOUNDARY` | 387 |
| `71/20/BOUNDARY` | 206 |
| `71/44/BOUNDARY` | 225 |
| `72/16/BOUNDARY` | 1 |
| `72/20/BOUNDARY` | 25 |
| `72/5/TEXT` | 1 |
| `86/20/BOUNDARY` | 1 |
| `93/44/BOUNDARY` | 35 |
| `94/20/BOUNDARY` | 11 |

## Interpretation

This diagnostic removes flat GDS elements by passive placement region. If Magic no longer reports a supply short on the stripped GDS, the short is localized to geometry inside those passive placement regions. This is not passive-aware LVS signoff; it is a localization experiment.
