# Passive Geometry Strip Diagnostic

## Summary

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- Output GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\passive_geometry_strip_probe\intersects_margin_5000\SMCNR_SE_2st_AMP.intersects_margin_5000.gds`
- Mode: `intersects`
- Margin: `5000`
- Strip boxes: 2
- Stripped elements: 3395
- Kept elements: 3466
- Missing passive instances: `[]`

## Strip Boxes

| instance | placement | local bbox | strip bbox |
| --- | --- | --- | --- |
| `xr0` | `[14800, 14200]` | `[-275, -550, 4875, 20350]` | `[9525, 8650, 24675, 39550]` |
| `xc0` | `[400, 18400]` | `[-55, -50, 13055, 10650]` | `[-4655, 13350, 18455, 34050]` |

## Stripped By Layer

| layer/type | count |
| --- | ---: |
| `115/1/BOUNDARY` | 31 |
| `117/0/BOUNDARY` | 1 |
| `131/0/TEXT` | 3 |
| `150/2/BOUNDARY` | 1 |
| `150/3/BOUNDARY` | 1 |
| `150/4/BOUNDARY` | 1 |
| `150/5/BOUNDARY` | 1 |
| `155/100/BOUNDARY` | 1 |
| `155/2/BOUNDARY` | 1 |
| `155/27/BOUNDARY` | 1 |
| `155/3/BOUNDARY` | 1 |
| `155/4/BOUNDARY` | 1 |
| `155/5/BOUNDARY` | 1 |
| `208/1/BOUNDARY` | 6 |
| `64/20/BOUNDARY` | 10 |
| `65/20/BOUNDARY` | 35 |
| `66/20/BOUNDARY` | 43 |
| `66/44/BOUNDARY` | 851 |
| `67/16/BOUNDARY` | 4 |
| `67/20/BOUNDARY` | 222 |
| `67/44/BOUNDARY` | 166 |
| `67/5/TEXT` | 3 |
| `68/20/BOUNDARY` | 214 |
| `68/44/BOUNDARY` | 322 |
| `69/20/BOUNDARY` | 204 |
| `69/44/BOUNDARY` | 320 |
| `70/20/BOUNDARY` | 204 |
| `70/44/BOUNDARY` | 322 |
| `71/20/BOUNDARY` | 204 |
| `71/44/BOUNDARY` | 160 |
| `72/16/BOUNDARY` | 1 |
| `72/20/BOUNDARY` | 21 |
| `72/5/TEXT` | 1 |
| `86/20/BOUNDARY` | 1 |
| `93/44/BOUNDARY` | 28 |
| `94/20/BOUNDARY` | 8 |

## Interpretation

This diagnostic removes flat GDS elements by passive placement region. If Magic no longer reports a supply short on the stripped GDS, the short is localized to geometry inside those passive placement regions. This is not passive-aware LVS signoff; it is a localization experiment.
