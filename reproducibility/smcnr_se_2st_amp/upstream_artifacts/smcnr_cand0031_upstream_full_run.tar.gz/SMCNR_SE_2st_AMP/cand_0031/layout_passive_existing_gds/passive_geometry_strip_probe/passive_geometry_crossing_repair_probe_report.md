# Passive Geometry Crossing Repair Probe

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- Crossing-stripped GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\passive_geometry_strip_probe\crossing_margin_0\SMCNR_SE_2st_AMP.crossing_margin_0.gds`
- Stripped crossing elements: `7`
- Supply short after crossing strip: `False`
- MOS connectivity after crossing strip: `mos_internal_net_mismatch`
- Passive-aware LVS trial after crossing strip: `fail`

## Crossing Samples

| layer/type | bbox | matching instances |
| --- | --- | --- |

## Interpretation

Deleting only the 7 GDS elements crossing passive placement boxes removes the Magic gnda/vdda supply short, but MOS/internal-net LVS still fails; this localizes the supply short to crossing route/power geometry around xr0/xc0, not to packet passive abstraction itself.
