# Passive Geometry Strip Diagnostic

## Summary

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- Output GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\passive_geometry_strip_probe\contains_margin_500\SMCNR_SE_2st_AMP.contains_margin_500.gds`
- Mode: `contains`
- Margin: `500`
- Strip boxes: 2
- Stripped elements: 1645
- Kept elements: 5216
- Missing passive instances: `[]`

## Strip Boxes

| instance | placement | local bbox | strip bbox |
| --- | --- | --- | --- |
| `xr0` | `[14800, 14200]` | `[-275, -550, 4875, 20350]` | `[14025, 13150, 20175, 35050]` |
| `xc0` | `[400, 18400]` | `[-55, -50, 13055, 10650]` | `[-155, 17850, 13955, 29550]` |

## Stripped By Layer

| layer/type | count |
| --- | ---: |
| `115/1/BOUNDARY` | 31 |
| `117/0/BOUNDARY` | 1 |
| `150/2/BOUNDARY` | 1 |
| `150/3/BOUNDARY` | 1 |
| `150/4/BOUNDARY` | 1 |
| `150/5/BOUNDARY` | 1 |
| `155/100/BOUNDARY` | 1 |
| `155/2/BOUNDARY` | 1 |
| `155/27/BOUNDARY` | 1 |
| `155/3/BOUNDARY` | 1 |
| `155/4/BOUNDARY` | 1 |
| `155/5/BOUNDARY` | 1 |
| `66/20/BOUNDARY` | 31 |
| `66/44/BOUNDARY` | 164 |
| `67/20/BOUNDARY` | 157 |
| `67/44/BOUNDARY` | 2 |
| `68/20/BOUNDARY` | 193 |
| `68/44/BOUNDARY` | 162 |
| `69/20/BOUNDARY` | 190 |
| `69/44/BOUNDARY` | 160 |
| `70/20/BOUNDARY` | 190 |
| `70/44/BOUNDARY` | 162 |
| `71/20/BOUNDARY` | 190 |
| `86/20/BOUNDARY` | 1 |
| `94/20/BOUNDARY` | 1 |

## Interpretation

This diagnostic removes flat GDS elements by passive placement region. If Magic no longer reports a supply short on the stripped GDS, the short is localized to geometry inside those passive placement regions. This is not passive-aware LVS signoff; it is a localization experiment.
