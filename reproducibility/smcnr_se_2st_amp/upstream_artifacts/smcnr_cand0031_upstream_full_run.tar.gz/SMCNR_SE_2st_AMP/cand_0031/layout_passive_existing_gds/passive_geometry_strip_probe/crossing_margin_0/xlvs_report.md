# Passive-Aware LVS Trial Netlist Preparation

## Summary

- Status: `ready_for_netgen_trial`
- Full passive-aware LVS proven: `False`
- Source output: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\passive_geometry_strip_probe\crossing_margin_0\xlvs\SMCNR_SE_2st_AMP_source.passive_aware.spice`
- Extracted output: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\passive_geometry_strip_probe\crossing_margin_0\xlvs\SMCNR_SE_2st_AMP_extracted.passive_aware.spice`
- Packet verification status: `candidate_requires_review`
- Source passives abstracted: `{'rppolywo_m': 1, 'cfmom_2t': 1}`
- Extracted physical passives removed: 0
- Extracted candidate passives inserted: 2
- Extracted parasitic capacitors removed: 69

## Interpretation

These netlists are a diagnostic MOS + packet-passive abstraction trial. They are closer to full passive-aware LVS than the passive-only comparison, but the extracted passive devices are still rewritten from packet evidence rather than recognized directly by Netgen as source devices.
