# LVS Preparation Report

## Outputs

- Input source netlist: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP_cand_0031.sp`
- Input Magic raw extracted netlist: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\SMCNR_SE_2st_AMP_identity_labels_extracted.spice`
- Raw extracted netlist copy: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\identity_label_lvs_prepare_diagnostic\SMCNR_SE_2st_AMP_extracted.raw.spice`
- Connectivity source netlist: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\identity_label_lvs_prepare_diagnostic\SMCNR_SE_2st_AMP_source.connectivity.spice`
- Connectivity extracted netlist: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\identity_label_lvs_prepare_diagnostic\SMCNR_SE_2st_AMP_extracted.connectivity.spice`

## Connectivity Normalization

- Dropped unsupported source passive devices: 2
- Deleted parasitic capacitor lines: 350
- Source MOS model aliases:
  - `nch_mac->sky130_fd_pr__nfet_01v8`: 3
  - `pch_mac->sky130_fd_pr__pfet_01v8`: 5
- Dropped source passive models:
  - `cfmom_2t`: 1
  - `rppolywo_m`: 1
- Removed MOS properties:
  - `ad`: 8
  - `as`: 8
  - `pd`: 8
  - `ps`: 8

## Net Renames

- Net rename enabled: no
- Power-net fixed baseline no longer requires `a_n15_90#` rename.

## Passive Abstraction Diagnostic

- Status: `physical_passives_partially_recover_source_terminals`
- Source passive devices: 2
- Extracted physical passive devices: 8
- Source passive terminals: `gnda`, `net027`, `outn`, `vout`
- Covered source passive terminals: `net027`, `outn`
- Missing source passive terminals: `gnda`, `vout`
- Extracted passives touching source passive terminals: 2
- Extracted passives touching source top ports: 0
- Self-loop extracted passives: 6
- Internal-only extracted passives: 6
- Source passive instances:
  - `xr0` `rppolywo_m` terminals: `net027`, `vout`, `gnda`
  - `xc0` `cfmom_2t` terminals: `outn`, `net027`
- Extracted passive model counts:
  - `sky130_fd_pr__res_generic_m1`: 2
  - `sky130_fd_pr__res_generic_m2`: 2
  - `sky130_fd_pr__res_generic_m3`: 2
  - `sky130_fd_pr__res_generic_m4`: 2
- Extracted passive examples:
  - `R0` `sky130_fd_pr__res_generic_m2` terminals: `m2_8082_3673#`, `m2_8082_3673#`
  - `R1` `sky130_fd_pr__res_generic_m1` terminals: `outn`, `a_660_2774#`
  - `R2` `sky130_fd_pr__res_generic_m4` terminals: `m2_8082_3673#`, `m2_8082_3673#`
  - `R3` `sky130_fd_pr__res_generic_m3` terminals: `m2_8082_3673#`, `m2_8082_3673#`
  - `R4` `sky130_fd_pr__res_generic_m2` terminals: `m2_8082_5771#`, `m2_8082_5771#`
  - `R5` `sky130_fd_pr__res_generic_m4` terminals: `m2_8082_5771#`, `m2_8082_5771#`
  - `R6` `sky130_fd_pr__res_generic_m3` terminals: `m2_8082_5771#`, `m2_8082_5771#`
  - `R7` `sky130_fd_pr__res_generic_m1` terminals: `net027_uq0`, `net027`

Interpretation: Some source passive terminals now appear on extracted physical passive devices, but the mapping is incomplete. Full passive-aware LVS still needs the remaining source terminals and source-instance abstraction to be recovered.

## LVS Type

This output is for connectivity LVS, not parasitic-aware LVS.
The raw Magic extraction is preserved separately so parasitic information is not lost.
