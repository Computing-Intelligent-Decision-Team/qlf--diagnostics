# Native Capacitor Flat-GDS Replacement

- Status: `native_cap_replacement_merged`
- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\xhigh_rb\rb.gds`
- Replacement GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\native_cap_replacement_candidate\SMCNR_SE_2st_AMP_xc0.gds`
- Output GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\native_cap_full_gds_trial_split\native_cap_replaced.gds`
- Source instance: `xc0`
- Translation DBU: `[46900, 23700]`
- Label retarget map: `{'C1': 'outn', 'C2': 'net027'}`
- Removed elements: 1252
- Preserved terminal elements: 8
- Inserted replacement elements: 675
- Terminal bridge status: `mim_m3_split_access_inserted`
- Bridge elements: 18

## Remaining Gates

- run Magic extraction on output_gds and prove a sky130_fd_pr__cap_* device has source terminals
- run DRC on output_gds after replacement
- run native passive retarget netgen after full candidate extraction includes both native resistor and native capacitor

## Removed By Layer

| layer/type | count |
| --- | ---: |
| `68/13/BOUNDARY` | 1 |
| `68/20/BOUNDARY` | 188 |
| `68/44/BOUNDARY` | 162 |
| `69/13/BOUNDARY` | 1 |
| `69/20/BOUNDARY` | 190 |
| `69/44/BOUNDARY` | 160 |
| `70/13/BOUNDARY` | 1 |
| `70/20/BOUNDARY` | 190 |
| `70/44/BOUNDARY` | 162 |
| `71/13/BOUNDARY` | 1 |
| `71/20/BOUNDARY` | 190 |
| `82/64/BOUNDARY` | 6 |
