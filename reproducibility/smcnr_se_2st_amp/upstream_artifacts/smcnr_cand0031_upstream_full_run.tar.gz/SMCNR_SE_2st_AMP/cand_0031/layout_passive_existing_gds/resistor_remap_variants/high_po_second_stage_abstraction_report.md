# Passive Abstraction Readiness Report

## Summary

- Status: `partial_passive_abstraction_readiness`
- Source passives: 2
- Extracted physical resistors: 8
- Extracted capacitors: 329
- Coordinate-parsed `.ext` devres devices: 8
- Coordinate-parsed `.ext` passive rsubckt devices: 0
- Source passives candidate for abstraction: 0
- Source passives with partial terminal recovery: 2
- Source resistors with segmented chain evidence: 0
- Source capacitors with plate-coupling evidence: 1
- Source-level abstraction candidates: 1
- Blockers: 7

## Source Passive Analysis

### `xr0` `rppolywo_m`

- Status: `partial_terminal_recovery`
- Expected kind: `resistor`
- Electrical terminals: `net027, vout`
- Body/reference terminals: `gnda`
- Covered terminals: `gnda, net027, vout`
- Missing terminals: `none`
- Expected-kind covered terminals: `net027`
- Missing from expected-kind devices: `gnda, vout`
- Coordinate-matched `.ext` devres devices: 0
- Coordinate-matched `.ext` resistor rsubckt devices: 0
- Segmented expected resistor chain present: False
- Capacitor plate-coupling evidence present: False
- Direct expected device present: False

Blockers:

- `missing_expected_kind_terminals:gnda,vout`
- `body_or_substrate_pin_has_no_magical_geometry:gnda`
- `no_extracted_resistor_between_expected_electrical_terminals`
- `no_coordinate_matched_extracted_resistor_for_source_instance`

Touching extracted resistors:

| instance | model | terminals | roles |
| --- | --- | --- | --- |
| `R7` | `sky130_fd_pr__res_generic_m1` | `net027_uq0 net027` | `split:net027<-net027_uq0; exact:net027<-net027` |

Coordinate-matched `.ext` devres devices:

- none

Coordinate-matched `.ext` resistor rsubckt devices:

- none

Segmented expected resistor chain:

- none (`missing_source_terminal_on_resistor_graph`)

Capacitor plate-coupling evidence:

- none (`not_capacitor`)

Source-level abstraction candidate:

- none

Touching extracted capacitors:

| instance | terminals | value | roles |
| --- | --- | --- | --- |
| `C4` | `a_10945_4000# vout` | `0` | `exact:vout<-vout` |
| `C5` | `net027 a_11805_6470#` | `0.06956f` | `exact:net027<-net027` |
| `C9` | `net027_uq0 m2_8082_5771#` | `0.31275f` | `split:net027<-net027_uq0` |
| `C21` | `vout m1_8070_3670#` | `0.18298f` | `exact:vout<-vout` |
| `C28` | `net027 a_11805_4650#` | `0` | `exact:net027<-net027` |
| `C34` | `m4_8070_3670# vout` | `0.00597f` | `exact:vout<-vout` |
| `C47` | `vout ibias` | `0.26043f` | `exact:vout<-vout` |
| `C52` | `a_10945_4260# vout` | `0` | `exact:vout<-vout` |
| `C56` | `net027 a_10945_4000#` | `0` | `exact:net027<-net027` |
| `C58` | `net027 a_11805_4390#` | `0` | `exact:net027<-net027` |
| `C76` | `net027 a_10945_4780#` | `0` | `exact:net027<-net027` |
| `C78` | `net027_uq0 a_10945_5820#` | `0` | `split:net027<-net027_uq0` |
| `C79` | `a_10945_4520# vout` | `0` | `exact:vout<-vout` |
| `C81` | `net027 a_10945_5820#` | `0.01562f` | `exact:net027<-net027` |
| `C83` | `net027 a_10945_6080#` | `0.00206f` | `exact:net027<-net027` |
| `C84` | `a_10945_3480# vout` | `0.00109f` | `exact:vout<-vout` |
| ... | ... | ... | `88 more` |

### `xc0` `cfmom_2t`

- Status: `partial_terminal_recovery`
- Expected kind: `capacitor`
- Electrical terminals: `outn, net027`
- Body/reference terminals: `none`
- Covered terminals: `net027, outn`
- Missing terminals: `none`
- Expected-kind covered terminals: `net027, outn`
- Missing from expected-kind devices: `none`
- Coordinate-matched `.ext` devres devices: 8
- Coordinate-matched `.ext` resistor rsubckt devices: 0
- Segmented expected resistor chain present: False
- Capacitor plate-coupling evidence present: True
- Direct expected device present: False

Blockers:

- `source_capacitor_requires_plate_coupling_abstraction`
- `coordinate_matched_devices_are_resistor_markers_not_capacitor`
- `source_capacitor_touches_extracted_resistor_markers_not_a_capacitor_device`

Touching extracted resistors:

| instance | model | terminals | roles |
| --- | --- | --- | --- |
| `R1` | `sky130_fd_pr__res_generic_m1` | `outn a_660_2774#` | `exact:outn<-outn` |
| `R7` | `sky130_fd_pr__res_generic_m1` | `net027_uq0 net027` | `split:net027<-net027_uq0; exact:net027<-net027` |

Coordinate-matched `.ext` devres devices:

| model | ext coord | GDS coord | matched terminal |
| --- | --- | --- | --- |
| `sky130_fd_pr__res_generic_m4` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m4` | `(8070, 5768)` | `(40350, 28840)` | `net027` |
| `sky130_fd_pr__res_generic_m3` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m3` | `(8070, 5768)` | `(40350, 28840)` | `net027` |
| `sky130_fd_pr__res_generic_m2` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m2` | `(8070, 5768)` | `(40350, 28840)` | `net027` |
| `sky130_fd_pr__res_generic_m1` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m1` | `(8070, 5768)` | `(40350, 28840)` | `net027` |

Coordinate-matched `.ext` resistor rsubckt devices:

- none

Segmented expected resistor chain:

- none (`not_resistor`)

Capacitor plate-coupling evidence:

- Terminals: `outn, net027`
- Cross-plate capacitors: 4
- Cross-plate capacitance: 539.84 fF
- Plate node counts: `{'outn': 7, 'net027': 7}`

Source-level abstraction candidate:

- Status: `candidate_requires_review`
- Type: `plate_coupling_capacitor_source_equivalent`
- Source-equivalent SPICE: `xc0 outn net027 cfmom_2t`
- Unresolved checks: `source_capacitor_requires_plate_coupling_abstraction`
- Body/reference resolution:
  - none

Touching extracted capacitors:

| instance | terminals | value | roles |
| --- | --- | --- | --- |
| `C5` | `net027 a_11805_6470#` | `0.06956f` | `exact:net027<-net027` |
| `C9` | `net027_uq0 m2_8082_5771#` | `0.31275f` | `split:net027<-net027_uq0` |
| `C22` | `a_10945_3480# outn` | `0` | `exact:outn<-outn` |
| `C28` | `net027 a_11805_4650#` | `0` | `exact:net027<-net027` |
| `C30` | `outn m2_8082_3673#` | `0.31275f` | `exact:outn<-outn` |
| `C56` | `net027 a_10945_4000#` | `0` | `exact:net027<-net027` |
| `C58` | `net027 a_11805_4390#` | `0` | `exact:net027<-net027` |
| `C76` | `net027 a_10945_4780#` | `0` | `exact:net027<-net027` |
| `C78` | `net027_uq0 a_10945_5820#` | `0` | `split:net027<-net027_uq0` |
| `C81` | `net027 a_10945_5820#` | `0.01562f` | `exact:net027<-net027` |
| `C83` | `net027 a_10945_6080#` | `0.00206f` | `exact:net027<-net027` |
| `C87` | `a_10945_6600# net027` | `0.00365f` | `exact:net027<-net027` |
| `C97` | `net027 a_10945_5560#` | `0.00718f` | `exact:net027<-net027` |
| `C102` | `m2_8070_5768# net027` | `0.00644f` | `exact:net027<-net027` |
| `C104` | `a_10945_4260# net027` | `0` | `exact:net027<-net027` |
| `C136` | `a_10945_4520# net027` | `0` | `exact:net027<-net027` |
| ... | ... | ... | `18 more` |

## Interpretation

This report is an abstraction-readiness diagnostic. A `candidate_for_passive_abstraction` status means the extracted fragments have enough terminal and device-kind evidence to justify a future LVS rewrite rule; it is not by itself a full passive-aware LVS proof.
