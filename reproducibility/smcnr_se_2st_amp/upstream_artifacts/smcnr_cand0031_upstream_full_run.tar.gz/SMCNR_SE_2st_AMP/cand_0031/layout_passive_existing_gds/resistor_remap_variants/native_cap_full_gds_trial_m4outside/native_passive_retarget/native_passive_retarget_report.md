# Native Sky130 Passive Retarget LVS Trial

- Status: `native_passive_retarget_ready`
- Native resistor chain status: `pass`
- Native resistor chain device count: `31`
- Native capacitor device recognition status: `pass`
- Native capacitor device count: `1`
- Missing native source passive instances: `[]`
- Full native passive LVS ready: `True`
- Full native passive LVS proven: `True`

## Artifacts

- Source native passive netlist: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\native_cap_full_gds_trial_m4outside\native_passive_retarget\smc_m4outside_source_native_passive.spice`
- Candidate native passive netlist: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\native_cap_full_gds_trial_m4outside\native_passive_retarget\smc_m4outside_candidate_native_passive.spice`

## Native Passive Netgen

- Status: `pass`
- Report: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\native_cap_full_gds_trial_m4outside\native_passive_retarget\smc_m4outside_native_resistor_chain_netgen.out`
- Log: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\native_cap_full_gds_trial_m4outside\native_passive_retarget\smc_m4outside_native_resistor_chain_netgen.log`
