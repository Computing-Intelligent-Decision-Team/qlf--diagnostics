# Passive Abstraction Readiness Report

## Summary

- Status: `partial_passive_abstraction_readiness`
- Source passives: 2
- Extracted physical resistors: 39
- Extracted capacitors: 329
- Coordinate-parsed `.ext` devres devices: 8
- Coordinate-parsed `.ext` passive rsubckt devices: 31
- Source passives candidate for abstraction: 0
- Source passives with partial terminal recovery: 2
- Source resistors with segmented chain evidence: 1
- Source capacitors with plate-coupling evidence: 1
- Source-level abstraction candidates: 2
- Blockers: 6

## Source Passive Analysis

### `xr0` `rppolywo_m`

- Status: `partial_terminal_recovery`
- Expected kind: `resistor`
- Electrical terminals: `net027, vout`
- Body/reference terminals: `gnda`
- Covered terminals: `gnda, net027, vout`
- Missing terminals: `none`
- Expected-kind covered terminals: `net027, vout`
- Missing from expected-kind devices: `gnda`
- Coordinate-matched `.ext` devres devices: 0
- Coordinate-matched `.ext` resistor rsubckt devices: 27
- Segmented expected resistor chain present: True
- Capacitor plate-coupling evidence present: False
- Direct expected device present: False

Blockers:

- `missing_expected_kind_terminals:gnda`
- `body_or_substrate_pin_has_no_magical_geometry:gnda`
- `source_resistor_requires_segmented_chain_abstraction`

Touching extracted resistors:

| instance | model | terminals | roles |
| --- | --- | --- | --- |
| `X11` | `sky130_fd_pr__res_generic_po` | `vout a_11805_2830#` | `exact:vout<-vout` |
| `X18` | `sky130_fd_pr__res_generic_po` | `a_10945_6600# net027` | `exact:net027<-net027` |
| `R7` | `sky130_fd_pr__res_generic_m1` | `net027_uq0 net027` | `split:net027<-net027_uq0; exact:net027<-net027` |

Coordinate-matched `.ext` devres devices:

- none

Coordinate-matched `.ext` resistor rsubckt devices:

| model | ext coord | GDS coord | ownership | matched terminal |
| --- | --- | --- | --- | --- |
| `sky130_fd_pr__res_generic_po` | `(11005, 2830)` | `(55025, 14150)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 2960)` | `(55025, 14800)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 3090)` | `(55025, 15450)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 3220)` | `(55025, 16100)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 3350)` | `(55025, 16750)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 3480)` | `(55025, 17400)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 3610)` | `(55025, 18050)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 3740)` | `(55025, 18700)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 3870)` | `(55025, 19350)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 4000)` | `(55025, 20000)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 4130)` | `(55025, 20650)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 4260)` | `(55025, 21300)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 4390)` | `(55025, 21950)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 4520)` | `(55025, 22600)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 4650)` | `(55025, 23250)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 4780)` | `(55025, 23900)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_generic_po` | `(11005, 5430)` | `(55025, 27150)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 5560)` | `(55025, 27800)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 5690)` | `(55025, 28450)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 5820)` | `(55025, 29100)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 5950)` | `(55025, 29750)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 6080)` | `(55025, 30400)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 6210)` | `(55025, 31050)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 6340)` | `(55025, 31700)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 6470)` | `(55025, 32350)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 6600)` | `(55025, 33000)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 6730)` | `(55025, 33650)` | `nearest_source_passive_pin_box` | `net027` |

Segmented expected resistor chain:

- Terminals: `net027` -> `vout`
- Extracted nets: `net027` -> `vout`
- Segment count: 31
- Device path: `X18, X26, X3, X14, X23, X38, X10, X20, X31, X5, X16, X25, X0, X12, X22, X34, X7, X19, X30, X4, X13, X24, X36, X8, X21, X32, X6, X15, X28, X37, X11`
- Net path: `net027, a_10945_6600#, a_11805_6470#, a_10945_6340#, a_11805_6210#, a_10945_6080#, a_11805_5950#, a_10945_5820#, a_11805_5690#, a_10945_5560#, a_11805_5430#, a_10945_5300#, a_11805_5170#, a_10945_5040#, a_11805_4910#, a_10945_4780#, a_11805_4650#, a_10945_4520#, a_11805_4390#, a_10945_4260#, a_11805_4130#, a_10945_4000#, a_11805_3870#, a_10945_3740#, a_11805_3610#, a_10945_3480#, a_11805_3350#, a_10945_3220#, a_11805_3090#, a_10945_2960#, a_11805_2830#, vout`

Capacitor plate-coupling evidence:

- none (`not_capacitor`)

Source-level abstraction candidate:

- Status: `candidate_requires_review`
- Type: `segmented_resistor_chain_source_equivalent`
- Source-equivalent SPICE: `xr0 net027 vout gnda rppolywo_m`
- Unresolved checks: `body_or_substrate_pin_has_no_magical_geometry:gnda`
- Body/reference resolution:
  - `gnda` via `exact` from `gnda`

Touching extracted capacitors:

| instance | terminals | value | roles |
| --- | --- | --- | --- |
| `C4` | `a_10945_4520# net027` | `0` | `exact:net027<-net027` |
| `C6` | `net027_uq0 a_11805_5690#` | `0` | `split:net027<-net027_uq0` |
| `C15` | `net027 a_11805_5690#` | `0.02927f` | `exact:net027<-net027` |
| `C22` | `net027 a_11805_4130#` | `0` | `exact:net027<-net027` |
| `C25` | `net027 a_10945_5300#` | `0.00172f` | `exact:net027<-net027` |
| `C28` | `a_1340_n30# vout` | `0` | `exact:vout<-vout` |
| `C32` | `net027 a_11805_5430#` | `0.00465f` | `exact:net027<-net027` |
| `C35` | `a_11805_5950# net027` | `0.02659f` | `exact:net027<-net027` |
| `C37` | `m4_8070_5768# net027` | `0.00289f` | `exact:net027<-net027` |
| `C44` | `m5_2730_2640# vout` | `0.0012f` | `exact:vout<-vout` |
| `C56` | `a_10945_6340# net027` | `0.00106f` | `exact:net027<-net027` |
| `C59` | `m3_8070_3670# vout` | `0.00613f` | `exact:vout<-vout` |
| `C61` | `net027 m3_8070_5768#` | `0.00466f` | `exact:net027<-net027` |
| `C68` | `vin vout` | `0.01134f` | `exact:vout<-vout` |
| `C75` | `vdda vout` | `0.41621f` | `exact:vout<-vout` |
| `C78` | `a_11805_5170# net027` | `0.00159f` | `exact:net027<-net027` |
| ... | ... | ... | `88 more` |

### `xc0` `cfmom_2t`

- Status: `partial_terminal_recovery`
- Expected kind: `capacitor`
- Electrical terminals: `outn, net027`
- Body/reference terminals: `none`
- Covered terminals: `net027, outn`
- Missing terminals: `none`
- Expected-kind covered terminals: `net027, outn`
- Missing from expected-kind devices: `none`
- Coordinate-matched `.ext` devres devices: 8
- Coordinate-matched `.ext` resistor rsubckt devices: 4
- Segmented expected resistor chain present: False
- Capacitor plate-coupling evidence present: True
- Direct expected device present: False

Blockers:

- `source_capacitor_requires_plate_coupling_abstraction`
- `coordinate_matched_devices_are_resistor_markers_not_capacitor`
- `source_capacitor_touches_extracted_resistor_markers_not_a_capacitor_device`

Touching extracted resistors:

| instance | model | terminals | roles |
| --- | --- | --- | --- |
| `R1` | `sky130_fd_pr__res_generic_m1` | `outn a_660_2774#` | `exact:outn<-outn` |
| `X18` | `sky130_fd_pr__res_generic_po` | `a_10945_6600# net027` | `exact:net027<-net027` |
| `R7` | `sky130_fd_pr__res_generic_m1` | `net027_uq0 net027` | `split:net027<-net027_uq0; exact:net027<-net027` |

Coordinate-matched `.ext` devres devices:

| model | ext coord | GDS coord | matched terminal |
| --- | --- | --- | --- |
| `sky130_fd_pr__res_generic_m4` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m4` | `(8070, 5768)` | `(40350, 28840)` | `net027` |
| `sky130_fd_pr__res_generic_m3` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m3` | `(8070, 5768)` | `(40350, 28840)` | `net027` |
| `sky130_fd_pr__res_generic_m2` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m2` | `(8070, 5768)` | `(40350, 28840)` | `net027` |
| `sky130_fd_pr__res_generic_m1` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m1` | `(8070, 5768)` | `(40350, 28840)` | `net027` |

Coordinate-matched `.ext` resistor rsubckt devices:

| model | ext coord | GDS coord | ownership | matched terminal |
| --- | --- | --- | --- | --- |
| `sky130_fd_pr__res_generic_po` | `(11005, 4910)` | `(55025, 24550)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 5040)` | `(55025, 25200)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 5170)` | `(55025, 25850)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_generic_po` | `(11005, 5300)` | `(55025, 26500)` | `nearest_source_passive_pin_box` | `net027` |

Segmented expected resistor chain:

- none (`not_resistor`)

Capacitor plate-coupling evidence:

- Terminals: `outn, net027`
- Cross-plate capacitors: 4
- Cross-plate capacitance: 539.84 fF
- Plate node counts: `{'outn': 7, 'net027': 7}`

Source-level abstraction candidate:

- Status: `candidate_requires_review`
- Type: `plate_coupling_capacitor_source_equivalent`
- Source-equivalent SPICE: `xc0 outn net027 cfmom_2t`
- Unresolved checks: `source_capacitor_requires_plate_coupling_abstraction`
- Body/reference resolution:
  - none

Touching extracted capacitors:

| instance | terminals | value | roles |
| --- | --- | --- | --- |
| `C4` | `a_10945_4520# net027` | `0` | `exact:net027<-net027` |
| `C6` | `net027_uq0 a_11805_5690#` | `0` | `split:net027<-net027_uq0` |
| `C14` | `outn vdda` | `-0` | `exact:outn<-outn` |
| `C15` | `net027 a_11805_5690#` | `0.02927f` | `exact:net027<-net027` |
| `C22` | `net027 a_11805_4130#` | `0` | `exact:net027<-net027` |
| `C25` | `net027 a_10945_5300#` | `0.00172f` | `exact:net027<-net027` |
| `C32` | `net027 a_11805_5430#` | `0.00465f` | `exact:net027<-net027` |
| `C35` | `a_11805_5950# net027` | `0.02659f` | `exact:net027<-net027` |
| `C37` | `m4_8070_5768# net027` | `0.00289f` | `exact:net027<-net027` |
| `C56` | `a_10945_6340# net027` | `0.00106f` | `exact:net027<-net027` |
| `C61` | `net027 m3_8070_5768#` | `0.00466f` | `exact:net027<-net027` |
| `C78` | `a_11805_5170# net027` | `0.00159f` | `exact:net027<-net027` |
| `C126` | `a_11805_6210# net027` | `0.02715f` | `exact:net027<-net027` |
| `C137` | `outn a_11805_3610#` | `0` | `exact:outn<-outn` |
| `C138` | `a_11805_4910# net027` | `0` | `exact:net027<-net027` |
| `C139` | `a_10945_5040# net027` | `0` | `exact:net027<-net027` |
| ... | ... | ... | `18 more` |

## Interpretation

This report is an abstraction-readiness diagnostic. A `candidate_for_passive_abstraction` status means the extracted fragments have enough terminal and device-kind evidence to justify a future LVS rewrite rule; it is not by itself a full passive-aware LVS proof.
