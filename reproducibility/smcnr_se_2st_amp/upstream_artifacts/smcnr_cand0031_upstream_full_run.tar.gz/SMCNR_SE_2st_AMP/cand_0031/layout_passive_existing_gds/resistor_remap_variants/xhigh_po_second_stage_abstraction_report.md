# Passive Abstraction Readiness Report

## Summary

- Status: `partial_passive_abstraction_readiness`
- Source passives: 2
- Extracted physical resistors: 39
- Extracted capacitors: 350
- Coordinate-parsed `.ext` devres devices: 8
- Coordinate-parsed `.ext` passive rsubckt devices: 31
- Source passives candidate for abstraction: 0
- Source passives with partial terminal recovery: 2
- Source resistors with segmented chain evidence: 1
- Source capacitors with plate-coupling evidence: 1
- Source-level abstraction candidates: 2
- Blockers: 5

## Source Passive Analysis

### `xr0` `rppolywo_m`

- Status: `partial_terminal_recovery`
- Expected kind: `resistor`
- Electrical terminals: `net027, vout`
- Body/reference terminals: `gnda`
- Covered terminals: `gnda, net027, vout`
- Missing terminals: `none`
- Expected-kind covered terminals: `gnda, net027, vout`
- Missing from expected-kind devices: `none`
- Coordinate-matched `.ext` devres devices: 0
- Coordinate-matched `.ext` resistor rsubckt devices: 28
- Segmented expected resistor chain present: True
- Capacitor plate-coupling evidence present: False
- Direct expected device present: False

Blockers:

- `body_or_substrate_pin_has_no_magical_geometry:gnda`
- `source_resistor_requires_segmented_chain_abstraction`

Touching extracted resistors:

| instance | model | terminals | roles |
| --- | --- | --- | --- |
| `X0` | `sky130_fd_pr__res_xhigh_po` | `a_10945_5300# a_11789_5170# gnda` | `exact:gnda<-gnda` |
| `X3` | `sky130_fd_pr__res_xhigh_po` | `a_10945_6600# a_11789_6470# gnda` | `exact:gnda<-gnda` |
| `X5` | `sky130_fd_pr__res_xhigh_po` | `a_10945_2960# a_11789_3090# gnda` | `exact:gnda<-gnda` |
| `X6` | `sky130_fd_pr__res_xhigh_po` | `a_10945_4260# a_11789_4390# gnda` | `exact:gnda<-gnda` |
| `X7` | `sky130_fd_pr__res_xhigh_po` | `a_10945_5560# a_11789_5690# gnda` | `exact:gnda<-gnda` |
| `X8` | `sky130_fd_pr__res_xhigh_po` | `a_10945_3480# a_11789_3350# gnda` | `exact:gnda<-gnda` |
| `X10` | `sky130_fd_pr__res_xhigh_po` | `a_10945_4780# a_11789_4650# gnda` | `exact:gnda<-gnda` |
| `X11` | `sky130_fd_pr__res_xhigh_po` | `a_10945_3740# a_11789_3870# gnda` | `exact:gnda<-gnda` |
| `X12` | `sky130_fd_pr__res_xhigh_po` | `a_10945_6080# a_11789_5950# gnda` | `exact:gnda<-gnda` |
| `X13` | `sky130_fd_pr__res_xhigh_po` | `a_10945_2960# a_11789_2830# gnda` | `exact:gnda<-gnda` |
| `X14` | `sky130_fd_pr__res_xhigh_po` | `a_10945_5040# a_11789_5170# gnda` | `exact:gnda<-gnda` |
| `X15` | `sky130_fd_pr__res_xhigh_po` | `a_10945_4260# a_11789_4130# gnda` | `exact:gnda<-gnda` |
| `X16` | `sky130_fd_pr__res_xhigh_po` | `a_10945_6340# a_11789_6470# gnda` | `exact:gnda<-gnda` |
| `X17` | `sky130_fd_pr__res_xhigh_po` | `a_10945_3220# a_11789_3350# gnda` | `exact:gnda<-gnda` |
| `X18` | `sky130_fd_pr__res_xhigh_po` | `a_10945_5560# a_11789_5430# gnda` | `exact:gnda<-gnda` |
| `X19` | `sky130_fd_pr__res_xhigh_po` | `a_10945_4520# a_11789_4650# gnda` | `exact:gnda<-gnda` |
| `X20` | `sky130_fd_pr__res_xhigh_po` | `a_10945_5820# a_11789_5950# gnda` | `exact:gnda<-gnda` |
| `X21` | `sky130_fd_pr__res_xhigh_po` | `a_10945_3740# a_11789_3610# gnda` | `exact:gnda<-gnda` |
| `X23` | `sky130_fd_pr__res_xhigh_po` | `vout a_11789_2830# gnda` | `exact:vout<-vout; exact:gnda<-gnda` |
| `X24` | `sky130_fd_pr__res_xhigh_po` | `a_10945_5040# a_11789_4910# gnda` | `exact:gnda<-gnda` |
| `X25` | `sky130_fd_pr__res_xhigh_po` | `a_10945_6340# a_11789_6210# gnda` | `exact:gnda<-gnda` |
| `X26` | `sky130_fd_pr__res_xhigh_po` | `a_10945_4000# a_11789_4130# gnda` | `exact:gnda<-gnda` |
| `X28` | `sky130_fd_pr__res_xhigh_po` | `a_10945_5300# a_11789_5430# gnda` | `exact:gnda<-gnda` |
| `X29` | `sky130_fd_pr__res_xhigh_po` | `a_10945_3220# a_11789_3090# gnda` | `exact:gnda<-gnda` |
| `R7` | `sky130_fd_pr__res_generic_m1` | `net027_uq0 net027` | `split:net027<-net027_uq0; exact:net027<-net027` |
| `X30` | `sky130_fd_pr__res_xhigh_po` | `a_10945_6600# net027 gnda` | `exact:net027<-net027; exact:gnda<-gnda` |
| `X31` | `sky130_fd_pr__res_xhigh_po` | `a_10945_4520# a_11789_4390# gnda` | `exact:gnda<-gnda` |
| `X32` | `sky130_fd_pr__res_xhigh_po` | `a_10945_5820# a_11789_5690# gnda` | `exact:gnda<-gnda` |
| `X33` | `sky130_fd_pr__res_xhigh_po` | `a_10945_3480# a_11789_3610# gnda` | `exact:gnda<-gnda` |
| `X35` | `sky130_fd_pr__res_xhigh_po` | `a_10945_4780# a_11789_4910# gnda` | `exact:gnda<-gnda` |
| `X37` | `sky130_fd_pr__res_xhigh_po` | `a_10945_6080# a_11789_6210# gnda` | `exact:gnda<-gnda` |
| `X38` | `sky130_fd_pr__res_xhigh_po` | `a_10945_4000# a_11789_3870# gnda` | `exact:gnda<-gnda` |

Coordinate-matched `.ext` devres devices:

- none

Coordinate-matched `.ext` resistor rsubckt devices:

| model | ext coord | GDS coord | ownership | matched terminal |
| --- | --- | --- | --- | --- |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 2830)` | `(55105, 14150)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 2960)` | `(55105, 14800)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 3090)` | `(55105, 15450)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 3220)` | `(55105, 16100)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 3350)` | `(55105, 16750)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 3480)` | `(55105, 17400)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 3610)` | `(55105, 18050)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 3740)` | `(55105, 18700)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 3870)` | `(55105, 19350)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 4000)` | `(55105, 20000)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 4130)` | `(55105, 20650)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 4260)` | `(55105, 21300)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 4390)` | `(55105, 21950)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 4520)` | `(55105, 22600)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 4650)` | `(55105, 23250)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 4780)` | `(55105, 23900)` | `nearest_source_passive_pin_box` | `vout` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 5300)` | `(55105, 26500)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 5430)` | `(55105, 27150)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 5560)` | `(55105, 27800)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 5690)` | `(55105, 28450)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 5820)` | `(55105, 29100)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 5950)` | `(55105, 29750)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 6080)` | `(55105, 30400)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 6210)` | `(55105, 31050)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 6340)` | `(55105, 31700)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 6470)` | `(55105, 32350)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 6600)` | `(55105, 33000)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 6730)` | `(55105, 33650)` | `nearest_source_passive_pin_box` | `net027` |

Segmented expected resistor chain:

- Terminals: `net027` -> `vout`
- Extracted nets: `net027` -> `vout`
- Segment count: 31
- Device path: `X30, X3, X16, X25, X37, X12, X20, X32, X7, X18, X28, X0, X14, X24, X35, X10, X19, X31, X6, X15, X26, X38, X11, X21, X33, X8, X17, X29, X5, X13, X23`
- Net path: `net027, a_10945_6600#, a_11789_6470#, a_10945_6340#, a_11789_6210#, a_10945_6080#, a_11789_5950#, a_10945_5820#, a_11789_5690#, a_10945_5560#, a_11789_5430#, a_10945_5300#, a_11789_5170#, a_10945_5040#, a_11789_4910#, a_10945_4780#, a_11789_4650#, a_10945_4520#, a_11789_4390#, a_10945_4260#, a_11789_4130#, a_10945_4000#, a_11789_3870#, a_10945_3740#, a_11789_3610#, a_10945_3480#, a_11789_3350#, a_10945_3220#, a_11789_3090#, a_10945_2960#, a_11789_2830#, vout`

Capacitor plate-coupling evidence:

- none (`not_capacitor`)

Source-level abstraction candidate:

- Status: `candidate_requires_review`
- Type: `segmented_resistor_chain_source_equivalent`
- Source-equivalent SPICE: `xr0 net027 vout gnda rppolywo_m`
- Unresolved checks: `body_or_substrate_pin_has_no_magical_geometry:gnda`
- Body/reference resolution:
  - `gnda` via `exact` from `gnda`

Touching extracted capacitors:

| instance | terminals | value | roles |
| --- | --- | --- | --- |
| `C4` | `m5_2730_2640# vout` | `0.0012f` | `exact:vout<-vout` |
| `C17` | `a_10945_6340# net027` | `0` | `exact:net027<-net027` |
| `C21` | `m3_8070_3670# vout` | `0.00613f` | `exact:vout<-vout` |
| `C23` | `net027 m3_8070_5768#` | `0.00466f` | `exact:net027<-net027` |
| `C31` | `vin vout` | `0.01134f` | `exact:vout<-vout` |
| `C38` | `vdda vout` | `0.41621f` | `exact:vout<-vout` |
| `C41` | `a_11789_5170# net027` | `0.00122f` | `exact:net027<-net027` |
| `C59` | `m2_8070_3670# vout` | `0.00236f` | `exact:vout<-vout` |
| `C73` | `m5_3930_2640# vout` | `0` | `exact:vout<-vout` |
| `C79` | `vout a_11789_2830#` | `0.00354f` | `exact:vout<-vout` |
| `C80` | `a_11789_3090# vout` | `0` | `exact:vout<-vout` |
| `C84` | `a_10945_3740# vout` | `0` | `exact:vout<-vout` |
| `C89` | `vout a_3264_586#` | `0` | `exact:vout<-vout` |
| `C91` | `a_11789_6210# net027` | `0.04171f` | `exact:net027<-net027` |
| `C104` | `a_11789_4910# net027` | `0` | `exact:net027<-net027` |
| `C105` | `a_10945_5040# net027` | `0` | `exact:net027<-net027` |
| ... | ... | ... | `88 more` |

### `xc0` `cfmom_2t`

- Status: `partial_terminal_recovery`
- Expected kind: `capacitor`
- Electrical terminals: `outn, net027`
- Body/reference terminals: `none`
- Covered terminals: `net027, outn`
- Missing terminals: `none`
- Expected-kind covered terminals: `net027, outn`
- Missing from expected-kind devices: `none`
- Coordinate-matched `.ext` devres devices: 8
- Coordinate-matched `.ext` resistor rsubckt devices: 3
- Segmented expected resistor chain present: False
- Capacitor plate-coupling evidence present: True
- Direct expected device present: False

Blockers:

- `source_capacitor_requires_plate_coupling_abstraction`
- `coordinate_matched_devices_are_resistor_markers_not_capacitor`
- `source_capacitor_touches_extracted_resistor_markers_not_a_capacitor_device`

Touching extracted resistors:

| instance | model | terminals | roles |
| --- | --- | --- | --- |
| `R1` | `sky130_fd_pr__res_generic_m1` | `outn a_660_2774#` | `exact:outn<-outn` |
| `R7` | `sky130_fd_pr__res_generic_m1` | `net027_uq0 net027` | `split:net027<-net027_uq0; exact:net027<-net027` |
| `X30` | `sky130_fd_pr__res_xhigh_po` | `a_10945_6600# net027 gnda` | `exact:net027<-net027` |

Coordinate-matched `.ext` devres devices:

| model | ext coord | GDS coord | matched terminal |
| --- | --- | --- | --- |
| `sky130_fd_pr__res_generic_m4` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m4` | `(8070, 5768)` | `(40350, 28840)` | `net027` |
| `sky130_fd_pr__res_generic_m3` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m3` | `(8070, 5768)` | `(40350, 28840)` | `net027` |
| `sky130_fd_pr__res_generic_m2` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m2` | `(8070, 5768)` | `(40350, 28840)` | `net027` |
| `sky130_fd_pr__res_generic_m1` | `(8070, 3670)` | `(40350, 18350)` | `outn` |
| `sky130_fd_pr__res_generic_m1` | `(8070, 5768)` | `(40350, 28840)` | `net027` |

Coordinate-matched `.ext` resistor rsubckt devices:

| model | ext coord | GDS coord | ownership | matched terminal |
| --- | --- | --- | --- | --- |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 4910)` | `(55105, 24550)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 5040)` | `(55105, 25200)` | `nearest_source_passive_pin_box` | `net027` |
| `sky130_fd_pr__res_xhigh_po` | `(11021, 5170)` | `(55105, 25850)` | `nearest_source_passive_pin_box` | `net027` |

Segmented expected resistor chain:

- none (`not_resistor`)

Capacitor plate-coupling evidence:

- Terminals: `outn, net027`
- Cross-plate capacitors: 4
- Cross-plate capacitance: 539.84 fF
- Plate node counts: `{'outn': 7, 'net027': 7}`

Source-level abstraction candidate:

- Status: `candidate_requires_review`
- Type: `plate_coupling_capacitor_source_equivalent`
- Source-equivalent SPICE: `xc0 outn net027 cfmom_2t`
- Unresolved checks: `source_capacitor_requires_plate_coupling_abstraction`
- Body/reference resolution:
  - none

Touching extracted capacitors:

| instance | terminals | value | roles |
| --- | --- | --- | --- |
| `C17` | `a_10945_6340# net027` | `0` | `exact:net027<-net027` |
| `C23` | `net027 m3_8070_5768#` | `0.00466f` | `exact:net027<-net027` |
| `C41` | `a_11789_5170# net027` | `0.00122f` | `exact:net027<-net027` |
| `C91` | `a_11789_6210# net027` | `0.04171f` | `exact:net027<-net027` |
| `C103` | `outn a_11789_3610#` | `0` | `exact:outn<-outn` |
| `C104` | `a_11789_4910# net027` | `0` | `exact:net027<-net027` |
| `C105` | `a_10945_5040# net027` | `0` | `exact:net027<-net027` |
| `C112` | `net027 a_11789_6470#` | `0.11928f` | `exact:net027<-net027` |
| `C115` | `net027_uq0 m2_8082_5771#` | `0.31275f` | `split:net027<-net027_uq0` |
| `C132` | `a_10945_3480# outn` | `0` | `exact:outn<-outn` |
| `C138` | `net027 a_11789_4650#` | `0` | `exact:net027<-net027` |
| `C141` | `outn m2_8082_3673#` | `0.31275f` | `exact:outn<-outn` |
| `C169` | `net027 a_10945_4000#` | `0` | `exact:net027<-net027` |
| `C171` | `net027 a_11789_4390#` | `0` | `exact:net027<-net027` |
| `C191` | `net027 a_10945_4780#` | `0` | `exact:net027<-net027` |
| `C192` | `net027_uq0 a_10945_5820#` | `0` | `split:net027<-net027_uq0` |
| ... | ... | ... | `18 more` |

## Interpretation

This report is an abstraction-readiness diagnostic. A `candidate_for_passive_abstraction` status means the extracted fragments have enough terminal and device-kind evidence to justify a future LVS rewrite rule; it is not by itself a full passive-aware LVS proof.
