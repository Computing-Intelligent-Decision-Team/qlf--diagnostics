# MOS Connectivity Comparison

## Summary

- Status: `mos_internal_net_mismatch`
- Reason: Candidate MOS connectivity differs from the reference MOS role signatures.
- Full passive-aware LVS proven: `False`
- Issues: `missing_reference_mos_net_role_signatures`

## Device Counts

- Reference MOS devices: 8
- Candidate MOS devices: 8
- Reference classes: `{'pfet': 5, 'nfet': 3}`
- Candidate classes: `{'pfet': 5, 'nfet': 3}`

## Supply Role Check

- Reference supply roles: `{'vdd': 'vdda', 'vss': 'gnda', 'nfet_source_to_vss': 1, 'nfet_source_to_vdd': 0, 'nfet_source_other': 2, 'nfet_bulk_to_vss': 3, 'nfet_bulk_to_vdd': 0, 'nfet_bulk_other': 0, 'nfet_source_or_bulk_to_vss': 4, 'nfet_source_or_bulk_to_vdd': 0, 'nfet_source_or_bulk_other': 2, 'pfet_source_to_vdd': 2, 'pfet_source_to_vss': 0, 'pfet_source_other': 3, 'pfet_bulk_to_vdd': 5, 'pfet_bulk_to_vss': 0, 'pfet_bulk_other': 0, 'pfet_source_or_bulk_to_vdd': 7, 'pfet_source_or_bulk_to_vss': 0, 'pfet_source_or_bulk_other': 3, 'nfet_with_source_or_bulk_not_vss': [], 'pfet_with_source_or_bulk_not_vdd': []}`
- Candidate supply roles: `{'vdd': 'vdda', 'vss': 'gnda', 'nfet_source_to_vss': 1, 'nfet_source_to_vdd': 0, 'nfet_source_other': 2, 'nfet_bulk_to_vss': 3, 'nfet_bulk_to_vdd': 0, 'nfet_bulk_other': 0, 'nfet_source_or_bulk_to_vss': 4, 'nfet_source_or_bulk_to_vdd': 0, 'nfet_source_or_bulk_other': 2, 'pfet_source_to_vdd': 2, 'pfet_source_to_vss': 0, 'pfet_source_other': 3, 'pfet_bulk_to_vdd': 5, 'pfet_bulk_to_vss': 0, 'pfet_bulk_other': 0, 'pfet_source_or_bulk_to_vdd': 7, 'pfet_source_or_bulk_to_vss': 0, 'pfet_source_or_bulk_other': 3, 'nfet_with_source_or_bulk_not_vss': [], 'pfet_with_source_or_bulk_not_vdd': []}`

## Netgen Cross-Check

- Disconnected nodes: `[]`
- Net mismatch: `None`
- Source net count: `None`
- Candidate net count: `None`

## Missing Reference Net Role Signatures

- reference nets `['ibias']` with roles `{'pfet.gate': 3, 'pfet.source': 1}`
- reference nets `['outp']` with roles `{'nfet.gate': 2, 'nfet.source': 1, 'pfet.drain': 1}`

## Split-Net Repair Hints

| reference net | reference roles | candidate net group | combined roles |
| --- | --- | --- | --- |
| `['ibias']` | `{'pfet.gate': 3, 'pfet.source': 1}` | `['a_n15_2446#', 'ibias']` | `{'pfet.source': 1, 'pfet.gate': 3}` |
| `['outp']` | `{'nfet.gate': 2, 'nfet.source': 1, 'pfet.drain': 1}` | `['a_3585_n10#', 'outp']` | `{'nfet.source': 1, 'nfet.gate': 2, 'pfet.drain': 1}` |

## Exact-Role Rename Hints

- none

## Closest Candidate Role Matches

| reference net | reference roles | candidate net | shared roles | missing roles | extra roles |
| --- | --- | --- | ---: | --- | --- |
| `gnda` | `{'nfet.source': 1, 'nfet.bulk': 3, 'nfet.drain': 2}` | `gnda` | 6 | `{}` | `{}` |
| `gnda` | `{'nfet.source': 1, 'nfet.bulk': 3, 'nfet.drain': 2}` | `a_3585_n10#` | 1 | `{'nfet.bulk': 3, 'nfet.drain': 2}` | `{}` |
| `gnda` | `{'nfet.source': 1, 'nfet.bulk': 3, 'nfet.drain': 2}` | `outn` | 1 | `{'nfet.bulk': 3, 'nfet.drain': 2}` | `{'nfet.gate': 1, 'pfet.source': 1}` |
| `ibias` | `{'pfet.gate': 3, 'pfet.source': 1}` | `ibias` | 3 | `{'pfet.source': 1}` | `{}` |
| `ibias` | `{'pfet.gate': 3, 'pfet.source': 1}` | `a_n15_2446#` | 1 | `{'pfet.gate': 3}` | `{}` |
| `ibias` | `{'pfet.gate': 3, 'pfet.source': 1}` | `net53` | 1 | `{'pfet.gate': 3}` | `{'pfet.drain': 2}` |
| `net53` | `{'pfet.drain': 2, 'pfet.source': 1}` | `net53` | 3 | `{}` | `{}` |
| `net53` | `{'pfet.drain': 2, 'pfet.source': 1}` | `vdda` | 2 | `{'pfet.drain': 1}` | `{'pfet.source': 1, 'pfet.bulk': 5}` |
| `net53` | `{'pfet.drain': 2, 'pfet.source': 1}` | `a_n15_2446#` | 1 | `{'pfet.drain': 2}` | `{}` |
| `outn` | `{'nfet.gate': 1, 'nfet.source': 1, 'pfet.source': 1}` | `outn` | 3 | `{}` | `{}` |
| `outn` | `{'nfet.gate': 1, 'nfet.source': 1, 'pfet.source': 1}` | `a_3585_n10#` | 1 | `{'nfet.gate': 1, 'pfet.source': 1}` | `{}` |
| `outn` | `{'nfet.gate': 1, 'nfet.source': 1, 'pfet.source': 1}` | `a_n15_2446#` | 1 | `{'nfet.gate': 1, 'nfet.source': 1}` | `{}` |
| `outp` | `{'nfet.gate': 2, 'pfet.drain': 1, 'nfet.source': 1}` | `outp` | 3 | `{'nfet.source': 1}` | `{}` |
| `outp` | `{'nfet.gate': 2, 'pfet.drain': 1, 'nfet.source': 1}` | `outn` | 2 | `{'nfet.gate': 1, 'pfet.drain': 1}` | `{'pfet.source': 1}` |
| `outp` | `{'nfet.gate': 2, 'pfet.drain': 1, 'nfet.source': 1}` | `a_3585_n10#` | 1 | `{'nfet.gate': 2, 'pfet.drain': 1}` | `{}` |
| `vdda` | `{'pfet.drain': 1, 'pfet.bulk': 5, 'pfet.source': 2}` | `vdda` | 8 | `{}` | `{}` |
| `vdda` | `{'pfet.drain': 1, 'pfet.bulk': 5, 'pfet.source': 2}` | `net53` | 2 | `{'pfet.bulk': 5, 'pfet.source': 1}` | `{'pfet.drain': 1}` |
| `vdda` | `{'pfet.drain': 1, 'pfet.bulk': 5, 'pfet.source': 2}` | `outp` | 1 | `{'pfet.bulk': 5, 'pfet.source': 2}` | `{'nfet.gate': 2}` |
| `vin` | `{'pfet.gate': 1}` | `vin` | 1 | `{}` | `{}` |
| `vin` | `{'pfet.gate': 1}` | `vip` | 1 | `{}` | `{}` |
| `vin` | `{'pfet.gate': 1}` | `ibias` | 1 | `{}` | `{'pfet.gate': 2}` |
| `vip` | `{'pfet.gate': 1}` | `vin` | 1 | `{}` | `{}` |
| `vip` | `{'pfet.gate': 1}` | `vip` | 1 | `{}` | `{}` |
| `vip` | `{'pfet.gate': 1}` | `ibias` | 1 | `{}` | `{'pfet.gate': 2}` |
| `vout` | `{'nfet.drain': 1, 'pfet.drain': 1}` | `vout` | 2 | `{}` | `{}` |
| `vout` | `{'nfet.drain': 1, 'pfet.drain': 1}` | `outp` | 1 | `{'nfet.drain': 1}` | `{'nfet.gate': 2}` |
| `vout` | `{'nfet.drain': 1, 'pfet.drain': 1}` | `net53` | 1 | `{'nfet.drain': 1}` | `{'pfet.source': 1, 'pfet.drain': 1}` |

## Interpretation

This diagnostic compares MOS terminal-role connectivity only. A pass here would still not prove full passive-aware LVS; it would only show that the full passive-remapped extraction has not corrupted the MOS network relative to the MOS-only reference.
