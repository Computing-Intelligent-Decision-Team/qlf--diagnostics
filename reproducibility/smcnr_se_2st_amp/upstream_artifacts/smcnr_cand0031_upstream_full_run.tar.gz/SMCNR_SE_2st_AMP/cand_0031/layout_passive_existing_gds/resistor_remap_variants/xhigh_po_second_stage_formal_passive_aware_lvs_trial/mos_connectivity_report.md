# MOS Connectivity Comparison

## Summary

- Status: `supply_or_internal_net_mismatch`
- Reason: Candidate MOS connectivity has supply-role corruption or a disconnected VSS node.
- Full passive-aware LVS proven: `False`
- Issues: `candidate_vss_has_no_mos_terminal_roles, candidate_nfet_source_or_bulk_tied_to_vdd, missing_reference_mos_net_role_signatures, netgen_reports_vss_disconnected, netgen_reports_net_count_mismatch`

## Device Counts

- Reference MOS devices: 8
- Candidate MOS devices: 8
- Reference classes: `{'pfet': 5, 'nfet': 3}`
- Candidate classes: `{'pfet': 5, 'nfet': 3}`

## Supply Role Check

- Reference supply roles: `{'vdd': 'vdda', 'vss': 'gnda', 'nfet_source_to_vss': 1, 'nfet_source_to_vdd': 0, 'nfet_source_other': 2, 'nfet_bulk_to_vss': 3, 'nfet_bulk_to_vdd': 0, 'nfet_bulk_other': 0, 'nfet_source_or_bulk_to_vss': 4, 'nfet_source_or_bulk_to_vdd': 0, 'nfet_source_or_bulk_other': 2, 'pfet_source_to_vdd': 2, 'pfet_source_to_vss': 0, 'pfet_source_other': 3, 'pfet_bulk_to_vdd': 5, 'pfet_bulk_to_vss': 0, 'pfet_bulk_other': 0, 'pfet_source_or_bulk_to_vdd': 7, 'pfet_source_or_bulk_to_vss': 0, 'pfet_source_or_bulk_other': 3, 'nfet_with_source_or_bulk_not_vss': [], 'pfet_with_source_or_bulk_not_vdd': []}`
- Candidate supply roles: `{'vdd': 'vdda', 'vss': 'gnda', 'nfet_source_to_vss': 0, 'nfet_source_to_vdd': 2, 'nfet_source_other': 1, 'nfet_bulk_to_vss': 0, 'nfet_bulk_to_vdd': 3, 'nfet_bulk_other': 0, 'nfet_source_or_bulk_to_vss': 0, 'nfet_source_or_bulk_to_vdd': 5, 'nfet_source_or_bulk_other': 1, 'pfet_source_to_vdd': 3, 'pfet_source_to_vss': 0, 'pfet_source_other': 2, 'pfet_bulk_to_vdd': 5, 'pfet_bulk_to_vss': 0, 'pfet_bulk_other': 0, 'pfet_source_or_bulk_to_vdd': 8, 'pfet_source_or_bulk_to_vss': 0, 'pfet_source_or_bulk_other': 2, 'nfet_with_source_or_bulk_not_vss': [{'instance': 'X2', 'source': 'a_3585_n10#', 'bulk': 'vdda', 'line': 'X2 vdda a_1340_n30# a_3585_n10# vdda sky130_fd_pr__nfet_01v8 w=1.5 l=10'}, {'instance': 'X30', 'source': 'vdda', 'bulk': 'vdda', 'line': 'X30 vout vdda vdda vdda sky130_fd_pr__nfet_01v8 w=1.48 l=10'}, {'instance': 'X35', 'source': 'vdda', 'bulk': 'vdda', 'line': 'X35 vdda a_1340_n30# vdda vdda sky130_fd_pr__nfet_01v8 w=1.5 l=10'}], 'pfet_with_source_or_bulk_not_vdd': []}`

## Netgen Cross-Check

- Disconnected nodes: `['gnda']`
- Net mismatch: `True`
- Source net count: `10`
- Candidate net count: `11`

## Missing Reference Net Role Signatures

- reference nets `['gnda']` with roles `{'nfet.bulk': 3, 'nfet.drain': 2, 'nfet.source': 1}`
- reference nets `['ibias']` with roles `{'pfet.gate': 3, 'pfet.source': 1}`
- reference nets `['outn']` with roles `{'nfet.gate': 1, 'nfet.source': 1, 'pfet.source': 1}`
- reference nets `['outp']` with roles `{'nfet.gate': 2, 'nfet.source': 1, 'pfet.drain': 1}`
- reference nets `['vdda']` with roles `{'pfet.bulk': 5, 'pfet.drain': 1, 'pfet.source': 2}`

## Interpretation

This diagnostic compares MOS terminal-role connectivity only. A pass here would still not prove full passive-aware LVS; it would only show that the full passive-remapped extraction has not corrupted the MOS network relative to the MOS-only reference.
