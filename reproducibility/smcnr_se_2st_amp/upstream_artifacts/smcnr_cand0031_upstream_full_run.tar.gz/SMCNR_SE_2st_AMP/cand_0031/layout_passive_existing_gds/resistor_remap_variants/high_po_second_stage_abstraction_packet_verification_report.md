# Passive Abstraction Packet Verification

## Summary

- Source netlist: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP_cand_0031.sp`
- Packet JSON: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\high_po_second_stage_abstraction_packet.json`
- Status: `fail`
- Full passive-aware LVS proven: `False`
- Source passives: 2
- Candidates: 1
- All source passives have candidate: False
- All source-equivalent lines match source: False
- All candidate support verified: False
- Formal LVS abstraction ready: False
- Abstraction scope: `source_equivalent_passive_lvs_abstraction`
- Missing source passive instances: `xr0`
- Unresolved blockers: `source_capacitor_requires_plate_coupling_abstraction`
- Remaining unresolved blockers after formal abstraction: `none`
- Structural failures: `missing_candidate:xr0`

## Candidate Checks

| source instance | type | source line match | support verified | unresolved |
| --- | --- | --- | --- | --- |
| `xc0` | `plate_coupling_capacitor_source_equivalent` | True | True | `source_capacitor_requires_plate_coupling_abstraction` |

## Interpretation

A `formal_lvs_abstraction_verified` status means segmented resistor chains and plate-coupling capacitor evidence are strong enough to rewrite source passives as LVS primitive R/C devices. This is a formal abstraction layer, not native passive device recognition, and it still requires the rewritten MOS+passive netlists to pass Netgen before full passive-aware LVS can be claimed.
