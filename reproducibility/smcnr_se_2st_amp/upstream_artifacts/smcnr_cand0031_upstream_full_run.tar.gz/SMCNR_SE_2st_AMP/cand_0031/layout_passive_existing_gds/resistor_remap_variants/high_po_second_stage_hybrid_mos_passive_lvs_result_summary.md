# LVS Result Summary

- Netgen report: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\high_po_second_stage_hybrid_mos_passive_netgen_report.out`
- Netgen log: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\high_po_second_stage_hybrid_mos_passive_netgen.log`
- LVS status: **FAIL**
- Circuits match uniquely: no
- Netlists match uniquely: no
- Device mismatch detected: yes
- Net mismatch detected: yes
- Property mismatch detected: no
- Unmatched devices/nets detected: no

## Counts

| Metric | Source | Extracted |
| --- | --- | --- |
| Devices | unknown | unknown |
| Nets | 10 | 10 |

## Interpretation

- Property mismatch avoided by connectivity normalization: yes
- Most likely failure cause: unmatched or mismatched devices, net mismatch
