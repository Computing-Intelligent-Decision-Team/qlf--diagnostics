# GDS Structure Diagnostic

## Summary

- Top GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\gds\SMCNR_SE_2st_AMP_xc0.gds`
- Top GDS cells: 1
- Top GDS SREF/AREF count: 0
- Top GDS text labels: 0
- Source passive devices: 2
- Source passive instance names present in top GDS: 1
- Source passive terminal names present in top GDS: 0
- Generated passive GDS files found: 2

## Source Passive Name Presence

| instance | model | terminals | instance name in top GDS | terminals in top GDS |
| --- | --- | --- | --- | --- |
| `xr0` | `rppolywo_m` | `net027 vout gnda` | no | `none` |
| `xc0` | `cfmom_2t` | `outn net027` | yes | `none` |

## Top GDS Cells

| cell | refs | texts | element counts |
| --- | ---: | ---: | --- |
| `SMCNR_SE_2st_AMP_xc0` | 0 | 0 | `BOUNDARY:1254` |

## Top GDS Text Labels

- none

## Generated Passive GDS Files

| instance | path | cells | refs | texts |
| --- | --- | ---: | ---: | ---: |
| `xc0` | `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\gds\SMCNR_SE_2st_AMP_xc0.gds` | 1 | 0 | 0 |
| `xr0` | `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\gds\SMCNR_SE_2st_AMP_xr0.gds` | 1 | 0 | 0 |

## Interpretation

This diagnostic checks whether the GDS still carries source passive instance or terminal names.
If the top GDS is flattened and the generated passive GDS files have no port text labels, source-instance passive LVS cannot be proven from netlist extraction alone.