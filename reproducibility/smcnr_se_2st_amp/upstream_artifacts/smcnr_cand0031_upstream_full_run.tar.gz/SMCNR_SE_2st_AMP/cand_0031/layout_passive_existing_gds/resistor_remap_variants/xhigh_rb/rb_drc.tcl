puts "SKY130_ROUTE_BRIDGE_TRIAL: DRC for xhigh_po_second_stage"
gds read generated/analog_harness/smcnr_se_2st_amp/cand_0031/layout_passive_existing_gds/resistor_remap_variants/xhigh_rb/rb.gds
if {[catch {load SMCNR_SE_2st_AMP_flat} load_error]} {
    puts stderr "ERROR: failed to load SMCNR_SE_2st_AMP_flat"
    puts stderr $load_error
    quit -noprompt
}
drc check
drc count
quit -noprompt
