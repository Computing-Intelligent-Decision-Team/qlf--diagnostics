# MOS Route Bridge Injection

- Status: `bridges_inserted`
- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\generic_rb\rl.gds`
- Output GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\generic_rb\rb.gds`
- Bridge count: 2
- Max gap DBU: 200

## Bridges

| net | source instance | pin | role | route layer | gap DBU | bridge box |
| --- | --- | --- | --- | --- | --- | --- |
| `ibias` | `xm7` | 0 | `pfet.drain` | `li1` | 100 | `[-50, 12450, 50, 12550]` |
| `outp` | `xm1` | 0 | `nfet.drain` | `li1` | 100 | `[17950, 1450, 18050, 1550]` |

## Interpretation

Bridge geometry is derived from MOS split-net evidence plus MAGICAL route/pin intermediates. It is a physical GDS repair candidate; downstream DRC and LVS evidence must still pass before the candidate is treated as layout-verified.
