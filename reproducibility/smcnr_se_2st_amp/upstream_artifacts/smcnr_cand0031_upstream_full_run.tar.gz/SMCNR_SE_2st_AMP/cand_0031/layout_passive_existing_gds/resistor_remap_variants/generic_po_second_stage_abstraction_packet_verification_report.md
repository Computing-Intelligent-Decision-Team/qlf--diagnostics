# Passive Abstraction Packet Verification

## Summary

- Source netlist: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP_cand_0031.sp`
- Packet JSON: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\generic_po_second_stage_abstraction_packet.json`
- Status: `formal_lvs_abstraction_verified`
- Full passive-aware LVS proven: `False`
- Source passives: 2
- Candidates: 2
- All source passives have candidate: True
- All source-equivalent lines match source: True
- All candidate support verified: True
- Formal LVS abstraction ready: True
- Abstraction scope: `source_equivalent_passive_lvs_abstraction`
- Missing source passive instances: `none`
- Unresolved blockers: `body_or_substrate_pin_has_no_magical_geometry:gnda, source_capacitor_requires_plate_coupling_abstraction`
- Remaining unresolved blockers after formal abstraction: `none`
- Structural failures: `none`

## Candidate Checks

| source instance | type | source line match | support verified | unresolved |
| --- | --- | --- | --- | --- |
| `xc0` | `plate_coupling_capacitor_source_equivalent` | True | True | `source_capacitor_requires_plate_coupling_abstraction` |
| `xr0` | `segmented_resistor_chain_source_equivalent` | True | True | `body_or_substrate_pin_has_no_magical_geometry:gnda` |

## Interpretation

A `formal_lvs_abstraction_verified` status means segmented resistor chains and plate-coupling capacitor evidence are strong enough to rewrite source passives as LVS primitive R/C devices. This is a formal abstraction layer, not native passive device recognition, and it still requires the rewritten MOS+passive netlists to pass Netgen before full passive-aware LVS can be claimed.
