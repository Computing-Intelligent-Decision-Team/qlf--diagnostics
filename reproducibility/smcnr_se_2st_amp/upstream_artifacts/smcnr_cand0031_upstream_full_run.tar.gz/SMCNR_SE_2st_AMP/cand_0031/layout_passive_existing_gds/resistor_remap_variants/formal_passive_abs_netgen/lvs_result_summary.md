# LVS Result Summary

- Netgen report: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\formal_passive_abs_netgen\netgen_lvs.out`
- Netgen log: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\formal_passive_abs_netgen\netgen_lvs.log`
- LVS status: **PASS**
- Circuits match uniquely: yes
- Netlists match uniquely: yes
- Device mismatch detected: no
- Net mismatch detected: no
- Property mismatch detected: no
- Unmatched devices/nets detected: no

## Counts

| Metric | Source | Extracted |
| --- | --- | --- |
| Devices | 2 | 2 |
| Nets | 3 | 3 |

## Interpretation

- Property mismatch avoided by connectivity normalization: yes
- Most likely failure cause: none detected
