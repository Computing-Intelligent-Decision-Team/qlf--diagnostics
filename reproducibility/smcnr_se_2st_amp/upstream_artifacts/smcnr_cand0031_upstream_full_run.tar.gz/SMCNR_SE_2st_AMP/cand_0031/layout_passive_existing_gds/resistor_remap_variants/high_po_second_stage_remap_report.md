# GDS Remap Report

## Summary

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\SMCNR_SE_2st_AMP.sky130.experimental_passive.pinned_shapes.gds`
- Output GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\SMCNR_SE_2st_AMP.high_po_second_stage.gds`
- Export map: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\high_po_second_stage_map.yaml`
- Unique input layer/datatype pairs: 34
- Successfully remapped pairs: 1
- Preserved TBD pairs: 0
- Preserved unmapped pairs: 33
- Preserved excluded pairs: 0

The original MAGICAL GDS is not modified. This post-processing step rewrites confirmed MAGICAL internal layers to their proposed Sky130 GDS layer/datatype targets. TBD and unmapped layers are left unchanged.
Experimental datatype-specific mappings enabled: yes.
Excluded input layer/datatype pairs: []

## Layer Actions

| input layer | input datatype | element type | output layer | output datatype | action | mapping |
| ---: | ---: | --- | ---: | ---: | --- | --- |
| 64 | 20 | BOUNDARY | 64 | 20 | preserved_unmapped | not listed in export map |
| 65 | 20 | BOUNDARY | 65 | 20 | preserved_unmapped | not listed in export map |
| 66 | 13 | BOUNDARY | 66 | 13 | preserved_unmapped | not listed in export map |
| 66 | 20 | BOUNDARY | 66 | 20 | preserved_unmapped | not listed in export map |
| 66 | 44 | BOUNDARY | 66 | 44 | preserved_unmapped | not listed in export map |
| 67 | 5 | TEXT | 67 | 5 | preserved_unmapped | not listed in export map |
| 67 | 16 | BOUNDARY | 67 | 16 | preserved_unmapped | not listed in export map |
| 67 | 20 | BOUNDARY | 67 | 20 | preserved_unmapped | not listed in export map |
| 67 | 44 | BOUNDARY | 67 | 44 | preserved_unmapped | not listed in export map |
| 68 | 5 | TEXT | 68 | 5 | preserved_unmapped | not listed in export map |
| 68 | 13 | BOUNDARY | 68 | 13 | preserved_unmapped | not listed in export map |
| 68 | 16 | BOUNDARY | 68 | 16 | preserved_unmapped | not listed in export map |
| 68 | 20 | BOUNDARY | 68 | 20 | preserved_unmapped | not listed in export map |
| 68 | 44 | BOUNDARY | 68 | 44 | preserved_unmapped | not listed in export map |
| 69 | 13 | BOUNDARY | 69 | 13 | preserved_unmapped | not listed in export map |
| 69 | 20 | BOUNDARY | 69 | 20 | preserved_unmapped | not listed in export map |
| 69 | 44 | BOUNDARY | 69 | 44 | preserved_unmapped | not listed in export map |
| 70 | 13 | BOUNDARY | 70 | 13 | preserved_unmapped | not listed in export map |
| 70 | 20 | BOUNDARY | 70 | 20 | preserved_unmapped | not listed in export map |
| 70 | 44 | BOUNDARY | 70 | 44 | preserved_unmapped | not listed in export map |
| 71 | 13 | BOUNDARY | 71 | 13 | preserved_unmapped | not listed in export map |
| 71 | 20 | BOUNDARY | 71 | 20 | preserved_unmapped | not listed in export map |
| 71 | 44 | BOUNDARY | 71 | 44 | preserved_unmapped | not listed in export map |
| 72 | 5 | TEXT | 72 | 5 | preserved_unmapped | not listed in export map |
| 72 | 16 | BOUNDARY | 72 | 16 | preserved_unmapped | not listed in export map |
| 72 | 20 | BOUNDARY | 72 | 20 | preserved_unmapped | not listed in export map |
| 79 | 20 | BOUNDARY | 95 | 20 | remapped | EXISTING_URPM -> npc.drawing 95/20 |
| 82 | 64 | BOUNDARY | 82 | 64 | preserved_unmapped | not listed in export map |
| 83 | 44 | BOUNDARY | 83 | 44 | preserved_unmapped | not listed in export map |
| 86 | 20 | BOUNDARY | 86 | 20 | preserved_unmapped | not listed in export map |
| 93 | 44 | BOUNDARY | 93 | 44 | preserved_unmapped | not listed in export map |
| 94 | 20 | BOUNDARY | 94 | 20 | preserved_unmapped | not listed in export map |
| 131 | 0 | TEXT | 131 | 0 | preserved_unmapped | not listed in export map |
| 136 | 0 | TEXT | 136 | 0 | preserved_unmapped | not listed in export map |

## Notes

- `remapped` means both GDS layer and datatype were replaced from `sky130_gds_export_map.yaml`.
- Datatype-specific overrides allow one MAGICAL layer number to map different input datatypes to different Sky130 targets.
- `preserved_tbd` means the MAGICAL layer exists in the export map but its Sky130 target is not confirmed.
- `preserved_unmapped` means the input GDS layer is not listed in the export map.
- `preserved_excluded` means the input layer/datatype matched an explicit exclusion override.
- This remap is a layer/datatype translation only; it does not make the layout Sky130 DRC-clean.
