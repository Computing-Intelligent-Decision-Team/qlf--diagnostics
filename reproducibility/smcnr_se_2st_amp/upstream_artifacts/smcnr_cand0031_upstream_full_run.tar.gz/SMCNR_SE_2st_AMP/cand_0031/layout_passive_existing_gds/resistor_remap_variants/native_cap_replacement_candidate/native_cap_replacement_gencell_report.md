# Sky130 Native Capacitor Gencell Probe

- Status: `pass`
- Model: `sky130_fd_pr__cap_mim_m3_1`
- Cell: `SMCNR_SE_2st_AMP_xc0`
- Size: `10.95um x 10.3um`
- Recognized devices: `1`
- Spice: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\native_cap_replacement_candidate\SMCNR_SE_2st_AMP_xc0.spice`
- GDS: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\native_cap_replacement_candidate\SMCNR_SE_2st_AMP_xc0.gds`
- Magic log: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\native_cap_replacement_candidate\native_cap_gencell_probe.magic.log`

## Extracted Devices

| Instance | Terminals | Model | Params |
| --- | --- | --- | --- |
| X0 | C1, C2 | sky130_fd_pr__cap_mim_m3_1 | l=10.3 w=10.95 |
