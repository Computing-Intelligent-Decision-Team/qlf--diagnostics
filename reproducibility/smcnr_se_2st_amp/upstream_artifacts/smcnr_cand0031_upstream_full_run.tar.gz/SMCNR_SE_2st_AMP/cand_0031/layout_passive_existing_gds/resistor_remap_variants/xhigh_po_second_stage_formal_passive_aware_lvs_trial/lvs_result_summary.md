# LVS Result Summary

- Netgen report: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\xhigh_po_second_stage_formal_passive_aware_lvs_trial\netgen_lvs.out`
- Netgen log: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\xhigh_po_second_stage_formal_passive_aware_lvs_trial\netgen_lvs.log`
- LVS status: **FAIL**
- Circuits match uniquely: no
- Netlists match uniquely: no
- Device mismatch detected: no
- Net mismatch detected: yes
- Property mismatch detected: no
- Unmatched devices/nets detected: no

## Counts

| Metric | Source | Extracted |
| --- | --- | --- |
| Devices | 10 | 10 |
| Nets | unknown | unknown |

## Interpretation

- Property mismatch avoided by connectivity normalization: yes
- Most likely failure cause: net mismatch
