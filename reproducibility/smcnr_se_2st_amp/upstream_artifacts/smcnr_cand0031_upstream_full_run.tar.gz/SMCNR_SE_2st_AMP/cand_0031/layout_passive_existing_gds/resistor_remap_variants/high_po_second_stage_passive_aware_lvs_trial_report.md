# Passive-Aware LVS Trial Netlist Preparation

## Summary

- Status: `packet_verification_failed`
- Full passive-aware LVS proven: `False`
- Source output: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\high_po_second_stage_passive_aware_lvs_trial\SMCNR_SE_2st_AMP_source.passive_aware.spice`
- Extracted output: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\high_po_second_stage_passive_aware_lvs_trial\SMCNR_SE_2st_AMP_extracted.passive_aware.spice`
- Packet verification status: `fail`
- Formal LVS abstraction ready: `False`
- Abstraction scope: `source_equivalent_passive_lvs_abstraction`
- Remaining unresolved blockers: `[]`
- Source passives abstracted: `{'rppolywo_m': 1, 'cfmom_2t': 1}`
- Extracted MOS connectivity source: `full_gds_extraction`
- MOS reference: `None`
- Extracted physical passives removed: 8
- Extracted candidate passives inserted: 1
- Extracted parasitic capacitors removed: 329

## Interpretation

These netlists are a MOS + formal packet-passive abstraction trial. Segmented resistor chains and cfmom plate-coupling evidence are rewritten to primitive R/C devices for LVS. This is a formal source-equivalent abstraction layer, not native Magic/Netgen recognition of every source passive device.

If `mos_connectivity_source=mos_reference`, the extracted-side MOS network was restored from a separately verified MOS-only extraction. That mode proves the passive abstraction can compose with a correct MOS network, but it does not prove the passive-inclusive full GDS extracted MOS network is correct.
