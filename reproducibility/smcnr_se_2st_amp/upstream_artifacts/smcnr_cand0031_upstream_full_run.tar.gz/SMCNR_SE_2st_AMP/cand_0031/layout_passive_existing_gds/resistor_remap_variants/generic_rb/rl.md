# Route Net Label Injection Report

## Summary

- Input GDS: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\SMCNR_SE_2st_AMP.generic_po_second_stage.identity_labels.gds`
- Route GR: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.gr`
- Output GDS: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\generic_rb\rl.gds`
- Target cell: `SMCNR_SE_2st_AMP_flat`
- Added TEXT labels: 25
- Added pin-purpose BOUNDARY shapes: 25
- This is an extraction-name recovery probe, not a physical LVS signoff claim.

## Injected Labels

| net | route id | route layer | box | label purpose | label center |
| --- | ---: | ---: | --- | --- | --- |
| `vdda` | 0 | 6 | `[-450, 11750, 10650, 11850]` | `met5.label 72/5` | `(5100, 11800)` |
| `vdda` | 1 | 6 | `[11750, 11750, 22850, 11850]` | `met5.label 72/5` | `(17300, 11800)` |
| `vdda` | 2 | 6 | `[2350, 16350, 13450, 16450]` | `met5.label 72/5` | `(7900, 16400)` |
| `gnda` | 15 | 6 | `[28150, -50, 28250, 1450]` | `met5.label 72/5` | `(28200, 700)` |
| `gnda` | 16 | 6 | `[16750, -50, 16850, 1450]` | `met5.label 72/5` | `(16800, 700)` |
| `gnda` | 17 | 6 | `[3150, 13950, 3250, 15450]` | `met5.label 72/5` | `(3200, 14700)` |
| `vin` | 20 | 1 | `[18350, 10550, 26850, 10650]` | `li1.label 67/5` | `(22600, 10600)` |
| `vip` | 21 | 1 | `[7950, 10550, 16450, 10650]` | `li1.label 67/5` | `(12200, 10600)` |
| `ibias` | 22 | 1 | `[-50, 12550, 10250, 12650]` | `li1.label 67/5` | `(5100, 12600)` |
| `ibias` | 23 | 1 | `[12150, 12550, 22450, 12650]` | `li1.label 67/5` | `(17300, 12600)` |
| `ibias` | 24 | 1 | `[2750, 17150, 13050, 17250]` | `li1.label 67/5` | `(7900, 17200)` |
| `vout` | 25 | 1 | `[12950, 16750, 13050, 17050]` | `li1.label 67/5` | `(13000, 16900)` |
| `vout` | 26 | 1 | `[13350, 13950, 13450, 15450]` | `li1.label 67/5` | `(13400, 14700)` |
| `vout` | 27 | 1 | `[54750, 14150, 54850, 14650]` | `li1.label 67/5` | `(54800, 14400)` |
| `outp` | 28 | 1 | `[17950, 1550, 28250, 1650]` | `li1.label 67/5` | `(23100, 1600)` |
| `outp` | 29 | 1 | `[6550, 1550, 16850, 1650]` | `li1.label 67/5` | `(11700, 1600)` |
| `outp` | 30 | 1 | `[26750, 2750, 26850, 10450]` | `li1.label 67/5` | `(26800, 6600)` |
| `outn` | 31 | 1 | `[6550, -50, 6650, 1450]` | `li1.label 67/5` | `(6600, 700)` |
| `outn` | 32 | 1 | `[7950, 2750, 8050, 10450]` | `li1.label 67/5` | `(8000, 6600)` |
| `outn` | 33 | 1 | `[3150, 15550, 13450, 15650]` | `li1.label 67/5` | `(8300, 15600)` |
| `net53` | 35 | 1 | `[22350, 12150, 22450, 12450]` | `li1.label 67/5` | `(22400, 12300)` |
| `net53` | 36 | 1 | `[16350, 2750, 16450, 10450]` | `li1.label 67/5` | `(16400, 6600)` |
| `net53` | 37 | 1 | `[18350, 2750, 18450, 10450]` | `li1.label 67/5` | `(18400, 6600)` |
| `net027` | 38 | 1 | `[59350, 33550, 59450, 34050]` | `li1.label 67/5` | `(59400, 33800)` |
| `net027` | 39 | 2 | `[40350, 28840, 53450, 29050]` | `met1.label 68/5` | `(46900, 28945)` |
