# Passive Identity Label Injection Report

## Summary

- Input GDS: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\SMCNR_SE_2st_AMP.xhigh_po_second_stage.gds`
- Output GDS: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\SMCNR_SE_2st_AMP.xhigh_po_second_stage.identity_labels.gds`
- Identity JSON: `generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\passive_identity_reconstruction_summary.json`
- Target cell: `SMCNR_SE_2st_AMP_flat`
- Added TEXT labels: 4
- Added pin-purpose BOUNDARY shapes: 4
- This is an experimental passive-aware extraction probe, not a full LVS claim.

## Injected Labels

| instance | terminal | box | label purpose | pin purpose | label center |
| --- | --- | --- | --- | --- | --- |
| `xr0` | `net027` | `[59350, 33550, 59450, 34050]` | `li1.label 67/5` | `li1.pin 67/16` | `(59400, 33800)` |
| `xr0` | `vout` | `[54750, 14150, 54850, 14650]` | `li1.label 67/5` | `li1.pin 67/16` | `(54800, 14400)` |
| `xc0` | `outn` | `[40350, 18350, 53450, 18560]` | `met1.label 68/5` | `met1.pin 68/16` | `(46900, 18455)` |
| `xc0` | `net027` | `[40350, 28840, 53450, 29050]` | `met1.label 68/5` | `met1.pin 68/16` | `(46900, 28945)` |

## Interpretation

The inserted labels come from exact matches between reconstructed passive pin boxes and MAGICAL source-net route rectangles.
A later Magic extraction pass must prove whether these labels are sufficient to recover source passive terminal names.