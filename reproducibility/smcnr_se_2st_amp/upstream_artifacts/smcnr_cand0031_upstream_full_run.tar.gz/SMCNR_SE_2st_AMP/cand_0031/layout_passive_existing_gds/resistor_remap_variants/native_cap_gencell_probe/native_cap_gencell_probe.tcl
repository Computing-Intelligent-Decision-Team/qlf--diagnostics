crashbackups stop
set gname sky130_native_cap_gencell_probe
cellname create $gname
pushstack $gname
set params [sky130::sky130_fd_pr__cap_mim_m3_1_defaults]
dict set params w 10
dict set params l 10
dict set params doports 1
sky130::sky130_fd_pr__cap_mim_m3_1_draw $params
property library sky130
property gencell sky130_fd_pr__cap_mim_m3_1
property parameters $params
save $gname
gds write ${gname}.gds
extract all
ext2spice lvs
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice ${gname}.ext
quit -noprompt
