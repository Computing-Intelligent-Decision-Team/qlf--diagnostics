puts "SKY130_PASSIVE_RESISTOR_REMAP_VARIANT: extracting generic_po_second_stage"
gds read generated/analog_harness/smcnr_se_2st_amp/cand_0031/layout_passive_existing_gds/resistor_remap_variants/SMCNR_SE_2st_AMP.generic_po_second_stage.identity_labels.gds
if {[catch {load SMCNR_SE_2st_AMP_flat} load_error]} {
    puts stderr "ERROR: failed to load SMCNR_SE_2st_AMP_flat"
    puts stderr $load_error
    quit -noprompt
}
select top cell
extract all
ext2spice lvs
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice
quit -noprompt
