# GDS Structure Diagnostic

## Summary

- Top GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\resistor_remap_variants\native_cap_replacement_candidate\SMCNR_SE_2st_AMP_xc0.gds`
- Top GDS cells: 1
- Top GDS SREF/AREF count: 0
- Top GDS text labels: 2
- Source passive devices: 0
- Source passive instance names present in top GDS: 0
- Source passive terminal names present in top GDS: 0
- Generated passive GDS files found: 0

## Source Passive Name Presence

- none

## Top GDS Cells

| cell | refs | texts | element counts |
| --- | ---: | ---: | --- |
| `SMCNR_SE_2st_AMP_xc0` | 0 | 2 | `BOUNDARY:655, TEXT:2` |

## Top GDS Text Labels

| cell | label | layer/texttype | xy |
| --- | --- | --- | --- |
| `SMCNR_SE_2st_AMP_xc0` | `C2` | `71/5` | `6295,0` |
| `SMCNR_SE_2st_AMP_xc0` | `C1` | `71/5` | `-880,0` |

## Generated Passive GDS Files

- none

## Interpretation

This diagnostic checks whether the GDS still carries source passive instance or terminal names.
If the top GDS is flattened and the generated passive GDS files have no port text labels, source-instance passive LVS cannot be proven from netlist extraction alone.