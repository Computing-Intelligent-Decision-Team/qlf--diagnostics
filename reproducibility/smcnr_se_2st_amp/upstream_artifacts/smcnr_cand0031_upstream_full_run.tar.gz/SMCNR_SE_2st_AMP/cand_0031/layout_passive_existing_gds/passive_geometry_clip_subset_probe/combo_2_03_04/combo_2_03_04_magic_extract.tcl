puts "SKY130_GDS_ELEMENT_SHORT_SUBSET_PROBE: reading selected-strip GDS"
gds read {/mnt/e/codex-magical-sky130-harness/magical-sky130-harness/generated/analog_harness/smcnr_se_2st_amp/cand_0031/layout_passive_existing_gds/passive_geometry_clip_subset_probe/combo_2_03_04/SMCNR_SE_2st_AMP.combo_2_03_04.gds}
if {[catch {load SMCNR_SE_2st_AMP_flat} load_error]} {
    puts stderr "ERROR: failed to load SMCNR_SE_2st_AMP_flat"
    puts stderr $load_error
    quit -noprompt
}
select top cell
extract all
ext2spice lvs
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice
quit -noprompt
