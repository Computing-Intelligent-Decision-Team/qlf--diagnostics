# GDS Element Short Subset Probe

## Summary

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- VDD/VSS: `vdda` / `gnda`
- Strip mode: `clip-crossing`
- Candidate elements: 7
- Probes run: 64
- Minimal short-free element set size: `3`
- Full passive-aware LVS proven: `False`

## Minimal Short-Free Sets

| probe | elements | MOS status |
| --- | --- | --- |
| `combo_3_00_01_03` | `e00:72/20/BOUNDARY:[10950, 2150, 11450, 35850], e01:72/20/BOUNDARY:[4150, 11550, 4650, 35850], e03:72/20/BOUNDARY:[9350, 16150, 9850, 35850]` | `mos_internal_net_mismatch` |

## Probe Results

| probe | stripped | clipped | supply short | MOS status |
| --- | ---: | ---: | --- | --- |
| `baseline_no_strip` | 0 | 0 | `True` | `None` |
| `combo_1_00` | 0 | 1 | `True` | `None` |
| `combo_1_01` | 0 | 1 | `True` | `None` |
| `combo_1_02` | 0 | 1 | `True` | `None` |
| `combo_1_03` | 0 | 1 | `True` | `None` |
| `combo_1_04` | 0 | 1 | `True` | `None` |
| `combo_1_05` | 0 | 1 | `True` | `None` |
| `combo_1_06` | 0 | 1 | `True` | `None` |
| `combo_2_00_01` | 0 | 2 | `True` | `None` |
| `combo_2_00_02` | 0 | 2 | `True` | `None` |
| `combo_2_00_03` | 0 | 2 | `True` | `None` |
| `combo_2_00_04` | 0 | 2 | `True` | `None` |
| `combo_2_00_05` | 0 | 2 | `True` | `None` |
| `combo_2_00_06` | 0 | 2 | `True` | `None` |
| `combo_2_01_02` | 0 | 2 | `True` | `None` |
| `combo_2_01_03` | 0 | 2 | `True` | `None` |
| `combo_2_01_04` | 0 | 2 | `True` | `None` |
| `combo_2_01_05` | 0 | 2 | `True` | `None` |
| `combo_2_01_06` | 0 | 2 | `True` | `None` |
| `combo_2_02_03` | 0 | 2 | `True` | `None` |
| `combo_2_02_04` | 0 | 2 | `True` | `None` |
| `combo_2_02_05` | 0 | 2 | `True` | `None` |
| `combo_2_02_06` | 0 | 2 | `True` | `None` |
| `combo_2_03_04` | 0 | 2 | `True` | `None` |
| `combo_2_03_05` | 0 | 2 | `True` | `None` |
| `combo_2_03_06` | 0 | 2 | `True` | `None` |
| `combo_2_04_05` | 0 | 2 | `True` | `None` |
| `combo_2_04_06` | 0 | 2 | `True` | `None` |
| `combo_2_05_06` | 0 | 2 | `True` | `None` |
| `combo_3_00_01_02` | 0 | 3 | `True` | `None` |
| `combo_3_00_01_03` | 0 | 3 | `False` | `mos_internal_net_mismatch` |
| `combo_3_00_01_04` | 0 | 3 | `True` | `None` |
| `combo_3_00_01_05` | 0 | 3 | `True` | `None` |
| `combo_3_00_01_06` | 0 | 3 | `True` | `None` |
| `combo_3_00_02_03` | 0 | 3 | `True` | `None` |
| `combo_3_00_02_04` | 0 | 3 | `True` | `None` |
| `combo_3_00_02_05` | 0 | 3 | `True` | `None` |
| `combo_3_00_02_06` | 0 | 3 | `True` | `None` |
| `combo_3_00_03_04` | 0 | 3 | `True` | `None` |
| `combo_3_00_03_05` | 0 | 3 | `True` | `None` |
| `combo_3_00_03_06` | 0 | 3 | `True` | `None` |
| `combo_3_00_04_05` | 0 | 3 | `True` | `None` |
| `combo_3_00_04_06` | 0 | 3 | `True` | `None` |
| `combo_3_00_05_06` | 0 | 3 | `True` | `None` |
| `combo_3_01_02_03` | 0 | 3 | `True` | `None` |
| `combo_3_01_02_04` | 0 | 3 | `True` | `None` |
| `combo_3_01_02_05` | 0 | 3 | `True` | `None` |
| `combo_3_01_02_06` | 0 | 3 | `True` | `None` |
| `combo_3_01_03_04` | 0 | 3 | `True` | `None` |
| `combo_3_01_03_05` | 0 | 3 | `True` | `None` |
| `combo_3_01_03_06` | 0 | 3 | `True` | `None` |
| `combo_3_01_04_05` | 0 | 3 | `True` | `None` |
| `combo_3_01_04_06` | 0 | 3 | `True` | `None` |
| `combo_3_01_05_06` | 0 | 3 | `True` | `None` |
| `combo_3_02_03_04` | 0 | 3 | `True` | `None` |
| `combo_3_02_03_05` | 0 | 3 | `True` | `None` |
| `combo_3_02_03_06` | 0 | 3 | `True` | `None` |
| `combo_3_02_04_05` | 0 | 3 | `True` | `None` |
| `combo_3_02_04_06` | 0 | 3 | `True` | `None` |
| `combo_3_02_05_06` | 0 | 3 | `True` | `None` |
| `combo_3_03_04_05` | 0 | 3 | `True` | `None` |
| `combo_3_03_04_06` | 0 | 3 | `True` | `None` |
| `combo_3_03_05_06` | 0 | 3 | `True` | `None` |
| `combo_3_04_05_06` | 0 | 3 | `True` | `None` |

## Interpretation

This is a localization probe only. A short-free selected-strip result means the selected GDS elements are sufficient to remove the Magic port short, but deleting geometry is not a layout repair and does not prove passive-aware LVS/PEX signoff.
