# GDS Element Short Subset Probe

## Summary

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- VDD/VSS: `vdda` / `gnda`
- Strip mode: `clip-crossing`
- Candidate elements: 7
- Probes run: 8
- Minimal short-free element set size: `None`
- Full passive-aware LVS proven: `False`

## Minimal Short-Free Sets

- none

## Probe Results

| probe | stripped | clipped | supply short | MOS status |
| --- | ---: | ---: | --- | --- |
| `baseline_no_strip` | 0 | 0 | `True` | `supply_or_internal_net_mismatch` |
| `combo_1_00` | 0 | 1 | `True` | `supply_or_internal_net_mismatch` |
| `combo_1_01` | 0 | 1 | `True` | `supply_or_internal_net_mismatch` |
| `combo_1_02` | 0 | 1 | `True` | `supply_or_internal_net_mismatch` |
| `combo_1_03` | 0 | 1 | `True` | `supply_or_internal_net_mismatch` |
| `combo_1_04` | 0 | 1 | `True` | `supply_or_internal_net_mismatch` |
| `combo_1_05` | 0 | 1 | `True` | `supply_or_internal_net_mismatch` |
| `combo_1_06` | 0 | 1 | `True` | `supply_or_internal_net_mismatch` |

## Interpretation

This is a localization probe only. A short-free selected-strip result means the selected GDS elements are sufficient to remove the Magic port short, but deleting geometry is not a layout repair and does not prove passive-aware LVS/PEX signoff.
