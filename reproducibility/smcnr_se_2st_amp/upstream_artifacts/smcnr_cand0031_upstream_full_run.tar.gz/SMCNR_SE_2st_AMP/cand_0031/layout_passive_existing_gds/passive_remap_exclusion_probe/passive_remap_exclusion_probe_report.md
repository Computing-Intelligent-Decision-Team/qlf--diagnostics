# Passive Remap Exclusion Probe

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- Export map: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\sky130PDK_trial\sky130_gds_export_map.yaml`

| excluded pair | vdda/gnda short | shorted ports |
| --- | --- | --- |
| `115:1` | `True` | `[['gnda', 'vdda']]` |
| `117:0` | `True` | `[['gnda', 'vdda']]` |
| `150:2` | `True` | `[['gnda', 'vdda']]` |
| `150:3` | `True` | `[['gnda', 'vdda']]` |
| `150:4` | `True` | `[['gnda', 'vdda']]` |
| `150:5` | `True` | `[['gnda', 'vdda']]` |
| `155:2` | `True` | `[['gnda', 'vdda']]` |
| `155:3` | `True` | `[['gnda', 'vdda']]` |
| `155:4` | `True` | `[['gnda', 'vdda']]` |
| `155:5` | `True` | `[['gnda', 'vdda']]` |
| `155:27` | `True` | `[['gnda', 'vdda']]` |
| `155:100` | `True` | `[['gnda', 'vdda']]` |
| `208:1` | `True` | `[['gnda', 'vdda']]` |

- Vdda/gnda short removed by: `[]`
