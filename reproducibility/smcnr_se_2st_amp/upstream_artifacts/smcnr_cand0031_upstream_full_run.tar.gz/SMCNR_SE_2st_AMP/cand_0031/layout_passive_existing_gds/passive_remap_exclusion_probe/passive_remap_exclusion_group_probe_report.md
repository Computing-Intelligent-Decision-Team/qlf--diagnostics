# Passive Remap Exclusion Group Probe

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- Export map: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\sky130PDK_trial\sky130_gds_export_map.yaml`

| group | vdda/gnda short | excluded pairs | shorted ports |
| --- | --- | --- | --- |
| `exclude_resistor_markers` | `True` | `[[115, 1], [117, 0]]` | `[['gnda', 'vdda']]` |
| `exclude_mrdmy` | `True` | `[[150, 2], [150, 3], [150, 4], [150, 5]]` | `[['gnda', 'vdda']]` |
| `exclude_tsv_ppi` | `True` | `[[155, 2], [155, 3], [155, 4], [155, 5], [155, 27], [155, 100]]` | `[['gnda', 'vdda']]` |
| `exclude_lvs_dummy` | `True` | `[[208, 1]]` | `[['gnda', 'vdda']]` |
| `exclude_mrdmy_tsv` | `True` | `[[150, 2], [150, 3], [150, 4], [150, 5], [155, 2], [155, 3], [155, 4], [155, 5], [155, 27], [155, 100]]` | `[['gnda', 'vdda']]` |
| `exclude_resistor_mrdmy` | `True` | `[[115, 1], [117, 0], [150, 2], [150, 3], [150, 4], [150, 5]]` | `[['gnda', 'vdda']]` |
| `exclude_resistor_tsv` | `True` | `[[115, 1], [117, 0], [155, 2], [155, 3], [155, 4], [155, 5], [155, 27], [155, 100]]` | `[['gnda', 'vdda']]` |
| `exclude_all_passive_experimental` | `True` | `[[115, 1], [117, 0], [150, 2], [150, 3], [150, 4], [150, 5], [155, 2], [155, 3], [155, 4], [155, 5], [155, 27], [155, 100], [208, 1]]` | `[['gnda', 'vdda']]` |

- Vdda/gnda short removed by groups: `[]`
