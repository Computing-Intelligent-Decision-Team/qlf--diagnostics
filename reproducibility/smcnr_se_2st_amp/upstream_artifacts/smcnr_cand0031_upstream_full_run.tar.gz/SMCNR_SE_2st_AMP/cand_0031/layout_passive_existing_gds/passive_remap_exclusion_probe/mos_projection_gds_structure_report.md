# GDS Structure Diagnostic

## Summary

- Top GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout\lvs_mos_projection_case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- Top GDS cells: 1
- Top GDS SREF/AREF count: 0
- Top GDS text labels: 12
- Source passive devices: 0
- Source passive instance names present in top GDS: 0
- Source passive terminal names present in top GDS: 0
- Generated passive GDS files found: 0

## Source Passive Name Presence

- none

## Top GDS Cells

| cell | refs | texts | element counts |
| --- | ---: | ---: | --- |
| `SMCNR_SE_2st_AMP_flat` | 0 | 12 | `BOUNDARY:5128, TEXT:12` |

## Top GDS Text Labels

| cell | label | layer/texttype | xy |
| --- | --- | --- | --- |
| `SMCNR_SE_2st_AMP_flat` | `vdda` | `136/0` | `9100,13800` |
| `SMCNR_SE_2st_AMP_flat` | `gnda` | `136/0` | `32000,700` |
| `SMCNR_SE_2st_AMP_flat` | `vin` | `131/0` | `26400,10600` |
| `SMCNR_SE_2st_AMP_flat` | `vip` | `131/0` | `16000,10600` |
| `SMCNR_SE_2st_AMP_flat` | `ibias` | `131/0` | `9100,14600` |
| `SMCNR_SE_2st_AMP_flat` | `vout` | `131/0` | `14000,12300` |
| `SMCNR_SE_2st_AMP_flat` | `vdda` | `72/5` | `21200,17075` |
| `SMCNR_SE_2st_AMP_flat` | `gnda` | `72/5` | `21200,-2800` |
| `SMCNR_SE_2st_AMP_flat` | `vin` | `67/5` | `26400,10600` |
| `SMCNR_SE_2st_AMP_flat` | `vip` | `67/5` | `16000,10600` |
| `SMCNR_SE_2st_AMP_flat` | `ibias` | `67/5` | `9100,14600` |
| `SMCNR_SE_2st_AMP_flat` | `vout` | `67/5` | `11600,7800` |

## Generated Passive GDS Files

- none

## Interpretation

This diagnostic checks whether the GDS still carries source passive instance or terminal names.
If the top GDS is flattened and the generated passive GDS files have no port text labels, source-instance passive LVS cannot be proven from netlist extraction alone.