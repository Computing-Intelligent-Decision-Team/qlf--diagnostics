# Passive Remap Baseline Probe

| scenario | vdda/gnda short | shorted ports |
| --- | --- | --- |
| `direct_input_gds` | `True` | `[['gnda', 'vdda']]` |
| `confirmed_only_remap` | `True` | `[['gnda', 'vdda']]` |