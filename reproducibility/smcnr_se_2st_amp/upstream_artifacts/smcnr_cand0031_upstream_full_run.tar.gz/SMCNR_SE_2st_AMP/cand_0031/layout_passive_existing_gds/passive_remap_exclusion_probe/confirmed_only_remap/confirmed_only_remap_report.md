# GDS Remap Report

## Summary

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- Output GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\passive_remap_exclusion_probe\confirmed_only_remap\SMCNR_SE_2st_AMP.confirmed_only.gds`
- Export map: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\sky130PDK_trial\sky130_gds_export_map.yaml`
- Unique input layer/datatype pairs: 37
- Successfully remapped pairs: 0
- Preserved TBD pairs: 19
- Preserved unmapped pairs: 18
- Preserved excluded pairs: 0

The original MAGICAL GDS is not modified. This post-processing step rewrites confirmed MAGICAL internal layers to their proposed Sky130 GDS layer/datatype targets. TBD and unmapped layers are left unchanged.
Experimental datatype-specific mappings enabled: no.
Excluded input layer/datatype pairs: []

## Layer Actions

| input layer | input datatype | element type | output layer | output datatype | action | mapping |
| ---: | ---: | --- | ---: | ---: | --- | --- |
| 64 | 20 | BOUNDARY | 64 | 20 | preserved_unmapped | not listed in export map |
| 65 | 20 | BOUNDARY | 65 | 20 | preserved_unmapped | not listed in export map |
| 66 | 20 | BOUNDARY | 66 | 20 | preserved_unmapped | not listed in export map |
| 66 | 44 | BOUNDARY | 66 | 44 | preserved_unmapped | not listed in export map |
| 67 | 5 | TEXT | 67 | 5 | preserved_tbd | VTH_N -> TBD |
| 67 | 16 | BOUNDARY | 67 | 16 | preserved_tbd | VTH_N -> TBD |
| 67 | 20 | BOUNDARY | 67 | 20 | preserved_tbd | VTH_N -> TBD |
| 67 | 44 | BOUNDARY | 67 | 44 | preserved_tbd | VTH_N -> TBD |
| 68 | 20 | BOUNDARY | 68 | 20 | preserved_tbd | VTH_P -> TBD |
| 68 | 44 | BOUNDARY | 68 | 44 | preserved_tbd | VTH_P -> TBD |
| 69 | 20 | BOUNDARY | 69 | 20 | preserved_unmapped | not listed in export map |
| 69 | 44 | BOUNDARY | 69 | 44 | preserved_unmapped | not listed in export map |
| 70 | 20 | BOUNDARY | 70 | 20 | preserved_unmapped | not listed in export map |
| 70 | 44 | BOUNDARY | 70 | 44 | preserved_unmapped | not listed in export map |
| 71 | 20 | BOUNDARY | 71 | 20 | preserved_unmapped | not listed in export map |
| 71 | 44 | BOUNDARY | 71 | 44 | preserved_unmapped | not listed in export map |
| 72 | 5 | TEXT | 72 | 5 | preserved_unmapped | not listed in export map |
| 72 | 16 | BOUNDARY | 72 | 16 | preserved_unmapped | not listed in export map |
| 72 | 20 | BOUNDARY | 72 | 20 | preserved_unmapped | not listed in export map |
| 86 | 20 | BOUNDARY | 86 | 20 | preserved_unmapped | not listed in export map |
| 93 | 44 | BOUNDARY | 93 | 44 | preserved_unmapped | not listed in export map |
| 94 | 20 | BOUNDARY | 94 | 20 | preserved_unmapped | not listed in export map |
| 115 | 1 | BOUNDARY | 115 | 1 | preserved_tbd | RPDMY[1] -> POLYRES 66/13 (experimental) |
| 117 | 0 | BOUNDARY | 117 | 0 | preserved_tbd | RH[0] -> URPM 79/20 (experimental) |
| 131 | 0 | TEXT | 131 | 0 | preserved_unmapped | not listed in export map |
| 136 | 0 | TEXT | 136 | 0 | preserved_unmapped | not listed in export map |
| 150 | 2 | BOUNDARY | 150 | 2 | preserved_tbd | MRDMY[2] -> MET1RES 68/13 (experimental) |
| 150 | 3 | BOUNDARY | 150 | 3 | preserved_tbd | MRDMY[3] -> MET2RES 69/13 (experimental) |
| 150 | 4 | BOUNDARY | 150 | 4 | preserved_tbd | MRDMY[4] -> MET3RES 70/13 (experimental) |
| 150 | 5 | BOUNDARY | 150 | 5 | preserved_tbd | MRDMY[5] -> MET4RES 71/13 (experimental) |
| 155 | 2 | BOUNDARY | 155 | 2 | preserved_tbd | TSV_PPI[2] -> CAPID 82/64 (experimental) |
| 155 | 3 | BOUNDARY | 155 | 3 | preserved_tbd | TSV_PPI[3] -> CAPID 82/64 (experimental) |
| 155 | 4 | BOUNDARY | 155 | 4 | preserved_tbd | TSV_PPI[4] -> CAPID 82/64 (experimental) |
| 155 | 5 | BOUNDARY | 155 | 5 | preserved_tbd | TSV_PPI[5] -> CAPID 82/64 (experimental) |
| 155 | 27 | BOUNDARY | 155 | 27 | preserved_tbd | TSV_PPI[27] -> CAPID 82/64 (experimental) |
| 155 | 100 | BOUNDARY | 155 | 100 | preserved_tbd | TSV_PPI[100] -> CAPID 82/64 (experimental) |
| 208 | 1 | BOUNDARY | 208 | 1 | preserved_tbd | LVS_DUMMY[1] -> LVSTEXT 83/44 (experimental) |

## Notes

- `remapped` means both GDS layer and datatype were replaced from `sky130_gds_export_map.yaml`.
- Datatype-specific overrides allow one MAGICAL layer number to map different input datatypes to different Sky130 targets.
- `preserved_tbd` means the MAGICAL layer exists in the export map but its Sky130 target is not confirmed.
- `preserved_unmapped` means the input GDS layer is not listed in the export map.
- `preserved_excluded` means the input layer/datatype matched an explicit exclusion override.
- This remap is a layer/datatype translation only; it does not make the layout Sky130 DRC-clean.
