# Passive Terminal Recovery Report

## Summary

- Status: `partial_source_passive_terminal_recovery`
- Source passive terminals: 4
- Covered source passive terminals: net027, outn
- Missing source passive terminals: gnda, vout
- Split source passive terminal candidates: 1
- Magic port shorts: 0

## Split Net Candidates

| source terminal | extracted terminal |
| --- | --- |
| `net027` | `net027_uq0` |

## Magic Port Shorts

- none

## Extracted Physical Passive Devices

| instance | model | terminals |
| --- | --- | --- |
| `R0` | `sky130_fd_pr__res_generic_m2` | `m2_8082_3673# m2_8082_3673#` |
| `R1` | `sky130_fd_pr__res_generic_m1` | `outn a_660_2774#` |
| `R2` | `sky130_fd_pr__res_generic_m4` | `m2_8082_3673# m2_8082_3673#` |
| `R3` | `sky130_fd_pr__res_generic_m3` | `m2_8082_3673# m2_8082_3673#` |
| `R4` | `sky130_fd_pr__res_generic_m2` | `m2_8082_5771# m2_8082_5771#` |
| `R5` | `sky130_fd_pr__res_generic_m4` | `m2_8082_5771# m2_8082_5771#` |
| `R6` | `sky130_fd_pr__res_generic_m3` | `m2_8082_5771# m2_8082_5771#` |
| `R7` | `sky130_fd_pr__res_generic_m1` | `net027_uq0 net027` |

## Interpretation

This report describes whether experimental identity labels caused Magic extraction to recover source passive terminal names. It is diagnostic evidence only; it is not a full passive-aware LVS proof.
