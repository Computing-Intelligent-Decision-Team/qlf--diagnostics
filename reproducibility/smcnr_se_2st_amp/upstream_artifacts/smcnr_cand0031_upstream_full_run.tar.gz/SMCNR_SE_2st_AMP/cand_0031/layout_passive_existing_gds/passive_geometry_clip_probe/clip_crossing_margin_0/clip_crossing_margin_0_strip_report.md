# Passive Geometry Strip Diagnostic

## Summary

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- Output GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\passive_geometry_clip_probe\clip_crossing_margin_0\SMCNR_SE_2st_AMP.clip_crossing_margin_0.gds`
- Mode: `clip-crossing`
- Margin: `0`
- Strip boxes: 2
- Stripped elements: 0
- Clipped crossing elements: 7
- Clipped fragments: 11
- Kept elements: 6854
- Missing passive instances: `[]`

## Strip Boxes

| instance | placement | local bbox | strip bbox |
| --- | --- | --- | --- |
| `xr0` | `[14800, 14200]` | `[-275, -550, 4875, 20350]` | `[14525, 13650, 19675, 34550]` |
| `xc0` | `[400, 18400]` | `[-55, -50, 13055, 10650]` | `[345, 18350, 13455, 29050]` |

## Stripped By Layer

- none

## Clipped By Layer

| layer/type | count |
| --- | ---: |
| `67/20/BOUNDARY` | 1 |
| `68/20/BOUNDARY` | 2 |
| `72/20/BOUNDARY` | 4 |

## Clipped Samples

| layer/type | original bbox | fragments | matching instances |
| --- | --- | --- | --- |
| `72/20/BOUNDARY` | `[10950, 2150, 11450, 35850]` | `[[10950, 2150, 11450, 18350], [10950, 29050, 11450, 35850]]` | `['xc0']` |
| `72/20/BOUNDARY` | `[4150, 11550, 4650, 35850]` | `[[4150, 11550, 4650, 18350], [4150, 29050, 4650, 35850]]` | `['xc0']` |
| `72/20/BOUNDARY` | `[18950, 11550, 19450, 35850]` | `[[18950, 11550, 19450, 13650], [18950, 34550, 19450, 35850]]` | `['xr0']` |
| `72/20/BOUNDARY` | `[9350, 16150, 9850, 35850]` | `[[9350, 16150, 9850, 18350], [9350, 29050, 9850, 35850]]` | `['xc0']` |
| `67/20/BOUNDARY` | `[13350, 14150, 14850, 14250]` | `[[13350, 14150, 14525, 14250]]` | `['xr0']` |
| `68/20/BOUNDARY` | `[13350, 18350, 13650, 18450]` | `[[13455, 18350, 13650, 18450]]` | `['xc0']` |
| `68/20/BOUNDARY` | `[13350, 28950, 19450, 29050]` | `[[13455, 28950, 14525, 29050]]` | `['xr0', 'xc0']` |

## Crossing Samples

- none

## Stripped Samples

- none

## Interpretation

This diagnostic removes flat GDS elements by passive placement region. If Magic no longer reports a supply short on the stripped GDS, the short is localized to geometry inside those passive placement regions. This is not passive-aware LVS signoff; it is a localization experiment.
