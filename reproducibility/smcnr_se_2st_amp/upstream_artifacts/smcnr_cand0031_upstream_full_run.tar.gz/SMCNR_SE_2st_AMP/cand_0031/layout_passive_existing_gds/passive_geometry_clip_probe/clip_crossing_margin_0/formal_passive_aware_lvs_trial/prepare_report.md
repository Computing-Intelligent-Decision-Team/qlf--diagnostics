# Passive-Aware LVS Trial Netlist Preparation

## Summary

- Status: `ready_for_netgen_trial`
- Full passive-aware LVS proven: `False`
- Source output: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\passive_geometry_clip_probe\clip_crossing_margin_0\formal_passive_aware_lvs_trial\SMCNR_SE_2st_AMP_source.passive_aware.spice`
- Extracted output: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\passive_geometry_clip_probe\clip_crossing_margin_0\formal_passive_aware_lvs_trial\SMCNR_SE_2st_AMP_extracted.passive_aware.spice`
- Packet verification status: `formal_lvs_abstraction_verified`
- Formal LVS abstraction ready: `True`
- Abstraction scope: `source_equivalent_passive_lvs_abstraction`
- Remaining unresolved blockers: `[]`
- Source passives abstracted: `{'rppolywo_m': 1, 'cfmom_2t': 1}`
- Extracted physical passives removed: 0
- Extracted candidate passives inserted: 2
- Extracted parasitic capacitors removed: 55

## Interpretation

These netlists are a MOS + formal packet-passive abstraction trial. Segmented resistor chains and cfmom plate-coupling evidence are rewritten to primitive R/C devices for LVS. This is a formal source-equivalent abstraction layer, not native Magic/Netgen recognition of every source passive device.
