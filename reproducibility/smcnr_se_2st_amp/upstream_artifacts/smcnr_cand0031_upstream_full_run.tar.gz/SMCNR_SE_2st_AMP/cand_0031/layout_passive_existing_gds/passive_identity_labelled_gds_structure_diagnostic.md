# GDS Structure Diagnostic

## Summary

- Top GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\SMCNR_SE_2st_AMP.sky130.experimental_passive.identity_labels.gds`
- Top GDS cells: 1
- Top GDS SREF/AREF count: 0
- Top GDS text labels: 16
- Source passive devices: 2
- Source passive instance names present in top GDS: 0
- Source passive terminal names present in top GDS: 4
- Generated passive GDS files found: 2

## Source Passive Name Presence

| instance | model | terminals | instance name in top GDS | terminals in top GDS |
| --- | --- | --- | --- | --- |
| `xr0` | `rppolywo_m` | `net027 vout gnda` | no | `net027 vout gnda` |
| `xc0` | `cfmom_2t` | `outn net027` | no | `outn net027` |

## Top GDS Cells

| cell | refs | texts | element counts |
| --- | ---: | ---: | --- |
| `SMCNR_SE_2st_AMP_flat` | 0 | 16 | `BOUNDARY:8352, TEXT:16` |

## Top GDS Text Labels

| cell | label | layer/texttype | xy |
| --- | --- | --- | --- |
| `SMCNR_SE_2st_AMP_flat` | `vdda` | `136/0` | `5100,11800` |
| `SMCNR_SE_2st_AMP_flat` | `gnda` | `136/0` | `28200,700` |
| `SMCNR_SE_2st_AMP_flat` | `vin` | `131/0` | `22600,10600` |
| `SMCNR_SE_2st_AMP_flat` | `vip` | `131/0` | `12200,10600` |
| `SMCNR_SE_2st_AMP_flat` | `ibias` | `131/0` | `5100,12600` |
| `SMCNR_SE_2st_AMP_flat` | `vout` | `131/0` | `13000,16900` |
| `SMCNR_SE_2st_AMP_flat` | `vdda` | `72/5` | `17400,36450` |
| `SMCNR_SE_2st_AMP_flat` | `gnda` | `72/5` | `17400,-2800` |
| `SMCNR_SE_2st_AMP_flat` | `vin` | `67/5` | `22600,10600` |
| `SMCNR_SE_2st_AMP_flat` | `vip` | `67/5` | `12200,10600` |
| `SMCNR_SE_2st_AMP_flat` | `ibias` | `67/5` | `5100,12600` |
| `SMCNR_SE_2st_AMP_flat` | `vout` | `68/5` | `34050,15400` |
| `SMCNR_SE_2st_AMP_flat` | `net027` | `67/5` | `59400,33800` |
| `SMCNR_SE_2st_AMP_flat` | `vout` | `67/5` | `54800,14400` |
| `SMCNR_SE_2st_AMP_flat` | `outn` | `68/5` | `46900,18455` |
| `SMCNR_SE_2st_AMP_flat` | `net027` | `68/5` | `46900,28945` |

## Generated Passive GDS Files

| instance | path | cells | refs | texts |
| --- | --- | ---: | ---: | ---: |
| `xc0` | `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\gds\SMCNR_SE_2st_AMP_xc0.gds` | 1 | 0 | 0 |
| `xr0` | `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\gds\SMCNR_SE_2st_AMP_xr0.gds` | 1 | 0 | 0 |

## Interpretation

This diagnostic checks whether the GDS still carries source passive instance or terminal names.
If the top GDS is flattened and the generated passive GDS files have no port text labels, source-instance passive LVS cannot be proven from netlist extraction alone.