# GDS Element Short Subset Probe

## Summary

- Input GDS: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\case\SMCNR_SE_2st_AMP.sky130.pinned_shapes.gds`
- VDD/VSS: `vdda` / `gnda`
- Candidate elements: 7
- Probes run: 8
- Minimal short-free element set size: `1`
- Full passive-aware LVS proven: `False`

## Minimal Short-Free Sets

| probe | elements | MOS status |
| --- | --- | --- |
| `combo_1_01` | `e01:72/20/BOUNDARY:[4150, 11550, 4650, 35850]` | `supply_or_internal_net_mismatch` |

## Probe Results

| probe | stripped | supply short | MOS status |
| --- | ---: | --- | --- |
| `baseline_no_strip` | 0 | `True` | `None` |
| `combo_1_00` | 1 | `True` | `None` |
| `combo_1_01` | 1 | `False` | `supply_or_internal_net_mismatch` |
| `combo_1_02` | 1 | `True` | `None` |
| `combo_1_03` | 1 | `True` | `None` |
| `combo_1_04` | 1 | `True` | `None` |
| `combo_1_05` | 1 | `True` | `None` |
| `combo_1_06` | 1 | `True` | `None` |

## Interpretation

This is a localization probe only. A short-free selected-strip result means the selected GDS elements are sufficient to remove the Magic port short, but deleting geometry is not a layout repair and does not prove passive-aware LVS/PEX signoff.
