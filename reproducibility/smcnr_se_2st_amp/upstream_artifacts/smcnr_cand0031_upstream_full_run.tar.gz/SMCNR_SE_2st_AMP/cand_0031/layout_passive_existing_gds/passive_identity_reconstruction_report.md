# Passive Identity Reconstruction Report

## Summary

- Status: `source_passive_pin_identity_reconstructed_from_magical_intermediates`
- Source passive devices: 2
- Source passive pins: 5
- Pins with MAGICAL geometry: 4
- Pins without MAGICAL geometry: 1
- Exact route matches: 4
- Overlap route matches: 0
- Missing route matches: 0
- Label injection candidates: 4

## Passive Pin Mapping

### `xr0`

- MAGICAL instance: `SMCNR_SE_2st_AMP_xr0`
- Model: `rppolywo_m`
- Placement origin: `[54800, 14200]`
- Pin shapes in `.pin`: 3

| pin | source terminal | local box | global box | route match | suggested Magic label | matched routes |
| ---: | --- | --- | --- | --- | --- | --- |
| 0 | `net027` | `[4550, 19350, 4650, 19850]` | `[59350, 33550, 59450, 34050]` | `exact` | `box 59350 33550 59450 34050; label net027 center li1` | `net027@L1:[59350, 33550, 59450, 34050]` |
| 1 | `vout` | `[-50, -50, 50, 450]` | `[54750, 14150, 54850, 14650]` | `exact` | `box 54750 14150 54850 14650; label vout center li1` | `vout@L1:[54750, 14150, 54850, 14650]` |
| 2 | `gnda` | `None` | `None` | `no_pin_geometry` | `none` | `none` |

### `xc0`

- MAGICAL instance: `SMCNR_SE_2st_AMP_xc0`
- Model: `cfmom_2t`
- Placement origin: `[40400, 18400]`
- Pin shapes in `.pin`: 2

| pin | source terminal | local box | global box | route match | suggested Magic label | matched routes |
| ---: | --- | --- | --- | --- | --- | --- |
| 0 | `outn` | `[-50, -50, 13050, 160]` | `[40350, 18350, 53450, 18560]` | `exact` | `box 40350 18350 53450 18560; label outn center met1` | `outn@L2:[40350, 18350, 53450, 18560]` |
| 1 | `net027` | `[-50, 10440, 13050, 10650]` | `[40350, 28840, 53450, 29050]` | `exact` | `box 40350 28840 53450 29050; label net027 center met1` | `net027@L2:[40350, 28840, 53450, 29050]` |

## Extracted Netlist Crosscheck

- Extracted netlist: `E:\codex-magical-sky130-harness\magical-sky130-harness\generated\analog_harness\smcnr_se_2st_amp\cand_0031\layout_passive_existing_gds\SMCNR_SE_2st_AMP_existing_pinned_gds_extracted.spice`
- Extracted physical passive devices: 8
- Source terminals present on extracted physical passive terminals: none

## Interpretation

MAGICAL placement/routing intermediates can recover source passive pin identity when pin boxes match source-net route rectangles.
This is not a full passive-aware LVS proof by itself; it is a placement-aware mapping artifact that can drive label injection or a future passive abstraction rule.